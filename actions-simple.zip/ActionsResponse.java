package ru.example.cash.contract;

import java.util.List;

public record ActionsResponse(List<ActionDto> actions) {
    public ActionsResponse {
        actions = List.copyOf(actions);
    }
}
