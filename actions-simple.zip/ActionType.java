package ru.example.cash.contract;

public enum ActionType {
    DOC_TYPE_CASHOUT, DOC_TYPE_CASHIN, HINT, FLAG
}
