package ru.example.cash.contract;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/** Immutable dictionary entry or evaluated action. Code remains extensible. */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ActionDto(
        String code,
        ActionType type,
        String name,
        String description,
        int order,
        @JsonProperty("isActive") boolean active,
        String notificationTypeCode,
        String successMessage,
        String disabledMessage) {

    public ActionDto evaluated(boolean enabled) {
        return new ActionDto(code, type, name, description, order, enabled,
                notificationTypeCode, successMessage, enabled ? null : disabledMessage);
    }
}
