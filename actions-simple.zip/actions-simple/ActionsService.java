package your.project.actions;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;
import your.project.actions.ActionDto.Type;

@Service
public class ActionsService {

    // TODO: внедрить через конструктор существующие репозиторий и сервисы проекта.

    public ActionsResponse getActions(Type type) {
        List<ActionDto> active = findActions().stream().filter(ActionDto::active).toList();
        if (active.isEmpty()) {
            // TODO: в анализе не решено: пустой ответ или ошибка.
            throw todo("Поведение при пустом активном справочнике");
        }
        if (type == Type.DOC_TYPE_CASHOUT
                && active.stream().noneMatch(a -> a.type() == Type.DOC_TYPE_CASHOUT)) {
            // TODO: в анализе не решено: ошибка или только флаги/подсказки.
            throw todo("Нет доступных записей типа DOC_TYPE_CASHOUT в справочнике");
        }

        List<ActionDto> actions = active.stream().filter(a -> matchesType(a.type(), type)).toList();
        if (actions.isEmpty()) {
            return new ActionsResponse(List.of());
        }
        Client client = getSelectedClient();
        boolean needsActivity = actions.stream().anyMatch(a ->
                a.type() == Type.DOC_TYPE_CASHOUT || "IS_UP_TO_DATE".equals(a.code()));
        // Один вызов проверки актуальности на запрос. Без mdmCode вызова нет.
        boolean upToDate = needsActivity && client.hasMdmCode() && isUpToDate(client.mdmCode());
        boolean documentsAllowed = client.hasMdmCode() && upToDate;
        List<ActionDto> result = new ArrayList<>();

        for (ActionDto action : actions) {
            switch (action.code()) {
                case "IS_CLIENT_SELECTED" -> result.add(action.withActive(client.hasMdmCode()));
                case "IS_REPRESENTATIVE_SELECTED" -> result.add(action.withActive(client.selected()));
                case "IS_UP_TO_DATE" -> {
                    if (!client.hasMdmCode()) {
                        throw todo("IS_UP_TO_DATE при отсутствии mdmCode");
                    }
                    result.add(action.withActive(upToDate));
                }
                case "CASHWITHCHECK" -> {
                    if (documentsAllowed && client.selected()) {
                        result.add(action.withActive(true));
                    } else {
                        // TODO: анализ допускает два варианта: скрыть или isActive=false.
                        throw todo("Скрывать или отключать CASHWITHCHECK");
                    }
                }
                case "CASH_NOTARY" -> {
                    // Итоговая матрица: mdmCode + Notary; на схеме добавлен isUpToDate.
                    // TODO: ранняя таблица также требует isClientSelected — согласовать.
                    if (documentsAllowed && "Notary".equals(client.legalStatus())) {
                        result.add(action.withActive(true));
                    }
                }
                case "CASHDELIVERY" -> {
                    if (documentsAllowed && client.selected() && isDeliveryEnabled()) {
                        result.add(action.withActive(true));
                    }
                }
                case "RKO_COMMISSION" -> {
                    if (documentsAllowed && client.selected() && hasExchangePermission()) {
                        result.add(action.withActive(true));
                    }
                }
                case "NOTARY_NOTIFICATION" -> {
                    // TODO: подтвердить дополнительные условия, если они есть;
                    // на схеме указано только отсутствие представителя.
                    if (!client.selected()) {
                        result.add(action.withActive(true));
                    }
                }
                case "OVN", "PCO_COMMISSION", "PCO_NOTARY" -> {
                    // TODO: проверки приходных документов в анализе не заполнены.
                    throw todo("Правило для " + action.code());
                }
                default -> throw todo("Правило для нового кода " + action.code());
            }
        }
        result.sort(Comparator.comparingInt(ActionDto::order).thenComparing(ActionDto::code));
        return new ActionsResponse(result);
    }

    private boolean matchesType(Type actual, Type requested) {
        // Для страницы документов сохраняем также общие флаги и подсказки.
        // TODO: подтвердить эту семантику type по окончательному контракту.
        return actual == requested || ((requested == Type.DOC_TYPE_CASHOUT
                || requested == Type.DOC_TYPE_CASHIN) && (actual == Type.FLAG || actual == Type.HINT));
    }

    private List<ActionDto> findActions() {
        // TODO: прочитать actions существующим репозиторием bank-cash и преобразовать
        // записи в ActionDto. Никакого HTTP-вызова bank-cash к самому себе.
        throw todo("Чтение справочника из репозитория");
    }

    private Client getSelectedClient() {
        // TODO: вызвать существующий сервис выбранного клиента; сопоставить
        // mdmCode, isClientSelected, mdmLegalStatusCode. Проверить обязательные поля.
        // Ошибку обработать по стандарту проекта, не подменять пустым клиентом.
        throw todo("Получение выбранного клиента");
    }

    private boolean isUpToDate(String mdmCode) {
        // TODO: вызвать существующий сервис актуальности; вернуть isUpToDate.
        // Ошибку обработать по стандарту проекта, не подменять значением false.
        throw todo("Проверка актуальности клиента");
    }

    private boolean isDeliveryEnabled() {
        // TODO: получить useCashDeliveryEnabled существующим сервисом.
        // По анализу при ожидаемом сбое этой проверки: записать причину в лог,
        // вернуть false (скрыть только CASHDELIVERY). Не ловить все Exception.
        throw todo("Проверка доставки наличных");
    }

    private boolean hasExchangePermission() {
        // TODO: вызвать существующий клиент bank_exchange, получить exchangePermission.
        // При ожидаемом сбое: лог без персональных данных и false для скрытия
        // только RKO_COMMISSION. Тип исключения зависит от клиента вашего проекта.
        throw todo("Получение полномочий операциониста");
    }

    // selected соответствует isClientSelected: в анализе он используется
    // для признака выбранного представителя, а наличие клиента определяется mdmCode.
    private record Client(String mdmCode, boolean selected, String legalStatus) {
        boolean hasMdmCode() {
            return mdmCode != null && !mdmCode.isBlank();
        }
    }

    private static UnsupportedOperationException todo(String message) {
        return new UnsupportedOperationException("TODO: " + message);
    }
}
