package your.project.actions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ActionDto(
        String code,
        Type type,
        String name,
        String description,
        int order,
        @JsonProperty("isActive") boolean active,
        String notificationTypeCode,
        String successMessage,
        String disabledMessage) {

    public enum Type { DOC_TYPE_CASHOUT, DOC_TYPE_CASHIN, FLAG, HINT }

    public ActionDto withActive(boolean value) {
        return new ActionDto(code, type, name, description, order, value,
                notificationTypeCode, successMessage, value ? null : disabledMessage);
    }
}
