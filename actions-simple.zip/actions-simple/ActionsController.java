package your.project.actions;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ActionsController {
    private final ActionsService service;

    public ActionsController(ActionsService service) {
        this.service = service;
    }

    // Можно перенести этот метод в существующий контроллер bank-cash.
    @GetMapping("/bank_cash/applic_list/actions")
    public ActionsResponse getActions(@RequestParam("type") ActionDto.Type type) {
        return service.getActions(type);
    }
}
