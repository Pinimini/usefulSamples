package your.project.actions;

import java.util.List;

public record ActionsResponse(List<ActionDto> actions) {
    public ActionsResponse {
        actions = List.copyOf(actions);
    }
}
