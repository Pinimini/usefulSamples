package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.business.regular.kasenc.bankcash.domain.cashin.Cashin;
import ru.vtb.business.regular.kasenc.bankcash.mapper.SpmMapper;
import ru.vtb.business.regular.kasenc.externalservices.frkk.service.FRKKSessionSecurityService;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmOutcome;
import ru.vtb.business.regular.kasenc.externalservices.spm.service.SpmActivityNotifier;
// TODO поправьте пакеты под свой проект
import ru.vtb.business.regular.kasenc.bankcash.domain.cashin.CashinNotification;
import ru.vtb.business.regular.kasenc.bankcash.domain.cashin.CashinNotificationCode;
import ru.vtb.business.regular.kasenc.bankcash.domain.cashin.CashinStatusCode;
import ru.vtb.business.regular.kasenc.bankcash.domain.cashin.CashinSubstatusCode;
import ru.vtb.business.regular.kasenc.bankcash.repository.CashinNotificationRepository;
import ru.vtb.business.regular.kasenc.bankcash.repository.CashinRepository;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.request.SpmAnalyzeRequest;

/**
 * Реакции приходного документа на первичную резолюцию (страница "POST api/v1/bank_cash/cashins").
 * Сущность — мок: проверяем, какие поля выставлены, и что сохранение идёт после них.
 */
@ExtendWith(MockitoExtension.class)
class CashinSpmHandlerTest {

    private static final OffsetDateTime SPM_ACTION_TIMESTAMP = OffsetDateTime.of(2026, 10, 11, 9, 0, 0, 0, ZoneOffset.UTC);
    private static final String EMPLOYEE_NUMBER = "1234567"; // TODO тип getEmployeeNumber(), если не String
    private static final String EMPLOYEE_LOGIN = "ivanov";

    @Mock
    private CashinRepository cashinRepository;
    @Mock
    private SpmActivityNotifier activityNotifier;
    @Mock
    private SpmMapper spmMapper;
    @Mock
    private CashinNotificationRepository cashinNotificationRepository;
    @Mock
    private FRKKSessionSecurityService frkkSessionSecurityService;

    @InjectMocks
    private CashinSpmHandler handler;

    private Cashin cashin;

    @BeforeEach
    void setUp() {
        cashin = mock(Cashin.class);
    }

    @Test
    void documentType() {
        assertThat(handler.documentType()).isEqualTo("CASHIN");
    }

    @Test
    @DisplayName("Запрос analyze строит SpmMapper (ОВН / ПКО нотариуса)")
    void buildAnalyzeRequest() {
        SpmAnalyzeRequest request = mock(SpmAnalyzeRequest.class);
        when(spmMapper.mapCashinOvnPkoNotaryDepToSpmAnalyzeRequest(cashin)).thenReturn(request);

        assertThat(handler.buildAnalyzeRequest(cashin)).isSameAs(request);
    }

    @Test
    @DisplayName("ALLOW: CONFIRMED, контролёр из сессии ФРКК, сохранение; сценарий продолжается")
    void allow() {
        when(frkkSessionSecurityService.getEmployeeNumber()).thenReturn(EMPLOYEE_NUMBER);
        when(frkkSessionSecurityService.getEmployeeLogin()).thenReturn(EMPLOYEE_LOGIN);

        SpmOutcome outcome = handler.onAllow(cashin);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        InOrder order = inOrder(cashin, cashinRepository);
        order.verify(cashin).setStatusCode(CashinStatusCode.CONFIRMED);
        order.verify(cashin).setSentToControlTimestamp(null);
        order.verify(cashin).setControlEmployeeNum(EMPLOYEE_NUMBER);
        order.verify(cashin).setControlEmployeeLogin(EMPLOYEE_LOGIN);
        order.verify(cashinRepository).save(cashin);
        verifyNoInteractions(activityNotifier);
    }

    @Test
    @DisplayName("DENY: DENIED / DENIED_SPM, нотификация и её описание; конец сценария")
    void deny() {
        givenNotification(CashinNotificationCode.DENIED_SPM, "Операция запрещена");

        SpmOutcome outcome = handler.onDeny(cashin);

        assertThat(outcome).isEqualTo(SpmOutcome.STOP);
        InOrder order = inOrder(cashin, cashinRepository);
        order.verify(cashin).setStatusCode(CashinStatusCode.DENIED);
        order.verify(cashin).setSubStatusCode(CashinSubstatusCode.DENIED_SPM);
        order.verify(cashin).setCashinNotificationCode(CashinNotificationCode.DENIED_SPM);
        order.verify(cashin).setReasonDescription("Операция запрещена");
        order.verify(cashinRepository).save(cashin);
        verifyNoInteractions(activityNotifier);
    }

    @Test
    @DisplayName("Нотификации нет в справочнике — reason_description = UNKNOWN")
    void notificationNotFound() {
        when(cashinNotificationRepository.findById(CashinNotificationCode.DENIED_SPM)).thenReturn(Optional.empty());

        handler.onDeny(cashin);

        verify(cashin).setReasonDescription("UNKNOWN");
    }

    @Test
    @DisplayName("REVIEW: CONTROL_SPM без субстатуса, дедлайн = spm_action_timestamp + 2 ч, SPM_CHECK_2; конец сценария")
    void review() {
        when(cashin.getSpmActionTimestamp()).thenReturn(SPM_ACTION_TIMESTAMP);
        givenNotification(CashinNotificationCode.SPM_CHECK_2, "Требуется дополнительная проверка");

        SpmOutcome outcome = handler.onReview(cashin);

        assertThat(outcome).isEqualTo(SpmOutcome.STOP);
        InOrder order = inOrder(cashin, cashinRepository);
        order.verify(cashin).setStatusCode(CashinStatusCode.CONTROL_SPM);
        order.verify(cashin).setSubStatusCode(null);
        order.verify(cashin).setSpmDeadline(SPM_ACTION_TIMESTAMP.plusHours(2));
        order.verify(cashin).setCashinNotificationCode(CashinNotificationCode.SPM_CHECK_2);
        order.verify(cashin).setReasonDescription("Требуется дополнительная проверка");
        order.verify(cashinRepository).save(cashin);
        verifyNoInteractions(activityNotifier);
    }

    @Test
    @DisplayName("Непредусмотренная: сохранение, затем EXECUTE; сценарий продолжается")
    void unexpected() {
        SpmOutcome outcome = handler.onUnexpected(cashin);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        InOrder order = inOrder(cashinRepository, activityNotifier);
        order.verify(cashinRepository).save(cashin);
        order.verify(activityNotifier).execute(cashin, "Получена непредусмотренная резолюция");
    }

    @Test
    @DisplayName("Недоступность СПМ: только сохранение; сценарий продолжается")
    void techChallenge() {
        SpmOutcome outcome = handler.onTechChallenge(cashin);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        verify(cashinRepository).save(cashin);
        verify(cashin, never()).setStatusCode(any());
        verifyNoInteractions(activityNotifier);
    }

    private void givenNotification(CashinNotificationCode code, String description) {
        CashinNotification notification = mock(CashinNotification.class);
        when(notification.getDescription()).thenReturn(description);
        when(cashinNotificationRepository.findById(code)).thenReturn(Optional.of(notification));
    }
}
