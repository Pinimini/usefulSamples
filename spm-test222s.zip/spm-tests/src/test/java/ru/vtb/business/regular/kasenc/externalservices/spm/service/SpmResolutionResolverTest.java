package ru.vtb.business.regular.kasenc.externalservices.spm.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmResolution;
// TODO поправьте пакеты ActionCode и SpmAnalyzeResponse под свой проект
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.response.ActionCode;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.response.SpmAnalyzeResponse;

/**
 * Таблица "если http-код = 200" первичной проверки — одинакова для заявки, РКО и ПКО.
 */
class SpmResolutionResolverTest {

    @ParameterizedTest(name = "actionCode={0}, actionSubCode={1} -> {2}")
    @CsvSource(nullValues = "NULL", value = {
            // 'ALLOW' при любом подкоде или без него
            "ALLOW,      NULL,  ALLOW",
            "ALLOW,      AML,   ALLOW",
            "ALLOW,      OTHER, ALLOW",
            // 'AML' + 'DENY' / 'REVIEW'
            "DENY,       AML,   DENY",
            "REVIEW,     AML,   REVIEW",
            // 'AML' + <> (ALLOW, DENY, REVIEW) или отсутствует
            "CHALLENGE,  AML,   UNEXPECTED",
            "AUTO_ALLOW, AML,   UNEXPECTED",
            "NULL,       AML,   UNEXPECTED",
            // <> 'AML' + <> 'ALLOW' или отсутствует
            "DENY,       NULL,  UNEXPECTED",
            "DENY,       OTHER, UNEXPECTED",
            "REVIEW,     NULL,  UNEXPECTED",
            "REVIEW,     OTHER, UNEXPECTED",
            "CHALLENGE,  OTHER, UNEXPECTED",
            "NULL,       NULL,  UNEXPECTED",
            // подкод отсутствует + 'CHALLENGE' -> недоступность СПМ
            "CHALLENGE,  NULL,  TECH_CHALLENGE",
            "CHALLENGE,  '',    TECH_CHALLENGE",
            "CHALLENGE,  '  ',  TECH_CHALLENGE",
    })
    void resolveByCodes(ActionCode actionCode, String actionSubCode, SpmResolution expected) {
        assertThat(SpmResolutionResolver.resolve(actionCode, actionSubCode)).isEqualTo(expected);
    }

    @Test
    @DisplayName("Код и подкод берутся из riskResult.triggeredRule")
    void resolveFromResponse() {
        SpmAnalyzeResponse response = mock(SpmAnalyzeResponse.class, RETURNS_DEEP_STUBS);
        when(response.getRiskResult().getTriggeredRule().getActionCode()).thenReturn(ActionCode.DENY);
        when(response.getRiskResult().getTriggeredRule().getActionSubCode()).thenReturn("AML");

        assertThat(SpmResolutionResolver.resolve(response)).isEqualTo(SpmResolution.DENY);
    }

    @Test
    @DisplayName("Пустой ответ -> непредусмотренная резолюция")
    void nullResponse() {
        assertThat(SpmResolutionResolver.resolve((SpmAnalyzeResponse) null)).isEqualTo(SpmResolution.UNEXPECTED);
    }

    @Test
    @DisplayName("Нет riskResult -> непредусмотренная резолюция")
    void noRiskResult() {
        SpmAnalyzeResponse response = mock(SpmAnalyzeResponse.class);

        assertThat(SpmResolutionResolver.resolve(response)).isEqualTo(SpmResolution.UNEXPECTED);
    }

    @Test
    @DisplayName("Нет triggeredRule -> непредусмотренная резолюция")
    void noTriggeredRule() {
        SpmAnalyzeResponse response = mock(SpmAnalyzeResponse.class, RETURNS_DEEP_STUBS);
        when(response.getRiskResult().getTriggeredRule()).thenReturn(null);

        assertThat(SpmResolutionResolver.resolve(response)).isEqualTo(SpmResolution.UNEXPECTED);
    }
}
