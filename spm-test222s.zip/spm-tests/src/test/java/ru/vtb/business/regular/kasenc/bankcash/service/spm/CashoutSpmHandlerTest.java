package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.Duration;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.business.regular.kasenc.bankcash.domain.cashout.Cashout;
import ru.vtb.business.regular.kasenc.bankcash.mapper.SpmMapper;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmOutcome;
import ru.vtb.business.regular.kasenc.externalservices.spm.service.SpmActivityNotifier;
// TODO поправьте пакеты под свой проект
import ru.vtb.business.regular.kasenc.bankcash.domain.Application;
import ru.vtb.business.regular.kasenc.bankcash.domain.cashout.CashoutNotificationCode;
import ru.vtb.business.regular.kasenc.bankcash.domain.cashout.CashoutStatusCode;
import ru.vtb.business.regular.kasenc.bankcash.repository.CashoutRepository;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.request.SpmAnalyzeRequest;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.response.ActionCode;

/**
 * Реакции расходного документа на первичную резолюцию (страница "POST api/v1/bank_cash/cashouts", п.16).
 * Сущности — моки: проверяем, какие поля выставлены и в каком порядке.
 */
@ExtendWith(MockitoExtension.class)
class CashoutSpmHandlerTest {

    private static final OffsetDateTime NOW = OffsetDateTime.of(2026, 10, 11, 12, 0, 0, 0, ZoneOffset.UTC);
    private static final String TECH_ALLOW_DESCRIPTION =
            "С момента проверки заявки на проведение операции прошло менее 12 часов (технический ALLOW)";

    @Mock
    private CashoutRepository cashoutRepository;
    @Mock
    private CashoutSpmActions actions;
    @Mock
    private SpmActivityNotifier activityNotifier;
    @Mock
    private SpmMapper spmMapper;

    @InjectMocks
    private CashoutSpmHandler handler;

    private Cashout cashout;

    @BeforeEach
    void setUp() {
        cashout = mock(Cashout.class);
    }

    @Test
    void documentType() {
        assertThat(handler.documentType()).isEqualTo("CASHOUT");
    }

    @Test
    @DisplayName("Запрос analyze строит SpmMapper")
    void buildAnalyzeRequest() {
        SpmAnalyzeRequest request = mock(SpmAnalyzeRequest.class);
        when(spmMapper.mapCashoutToSpmAnalyzeRequest(cashout)).thenReturn(request);

        assertThat(handler.buildAnalyzeRequest(cashout)).isSameAs(request);
    }

    @Test
    @DisplayName("ALLOW: статус CONTROL, затем задача на контролера")
    void allow() {
        SpmOutcome outcome = handler.onAllow(cashout);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        InOrder order = inOrder(cashout, actions);
        order.verify(cashout).setStatusCode(CashoutStatusCode.CONTROL);
        order.verify(actions).createControllerTask(cashout);
        verifyNoInteractions(activityNotifier);
    }

    @Test
    @DisplayName("DENY: РКО и связанная заявка отклоняются через CashoutSpmActions.deny")
    void deny() {
        SpmOutcome outcome = handler.onDeny(cashout);

        assertThat(outcome).isEqualTo(SpmOutcome.STOP);
        verify(actions).deny(cashout);
        verify(actions, never()).createControllerTask(any());
        verifyNoInteractions(activityNotifier);
    }

    // ----------------------------------------- REVIEW -----------------------------------------

    static Stream<Arguments> technicalAllowCases() {
        return Stream.of(
                Arguments.of("1 час с создания заявки", Duration.ofHours(1)),
                Arguments.of("11 ч 59 мин", Duration.ofHours(12).minusMinutes(1)),
                Arguments.of("заявка создана только что", Duration.ZERO)
        );
    }

    @ParameterizedTest(name = "{0}")
    @MethodSource("technicalAllowCases")
    @DisplayName("< 12 ч с создания заявки и у заявки REVIEW_ALLOW -> технический ALLOW")
    void technicalAllow(String caseName, Duration sinceApplication) {
        givenReview(sinceApplication, ActionCode.REVIEW_ALLOW);

        SpmOutcome outcome = handler.onReview(cashout);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        InOrder order = inOrder(cashout, actions, activityNotifier);
        order.verify(cashout).setSpmActionCode(ActionCode.AUTO_ALLOW);
        order.verify(cashout).setSpmActionTimestamp(any());
        order.verify(actions).createControllerTask(cashout);
        order.verify(activityNotifier).execute(cashout, TECH_ALLOW_DESCRIPTION);
        // ожидание уточнённой резолюции не запускается
        verify(cashout, never()).setSpmDeadline(any());
        verify(cashout, never()).setStatusCode(any());
        verifyNoInteractions(cashoutRepository);
    }

    @Test
    @DisplayName("Технический ALLOW обновляет spm_action_timestamp на текущее время")
    void technicalAllowUpdatesTimestamp() {
        givenReview(Duration.ofHours(1), ActionCode.REVIEW_ALLOW);
        OffsetDateTime before = OffsetDateTime.now();

        handler.onReview(cashout);

        ArgumentCaptor<OffsetDateTime> timestamp = ArgumentCaptor.forClass(OffsetDateTime.class);
        verify(cashout).setSpmActionTimestamp(timestamp.capture());
        assertThat(timestamp.getValue()).isBetween(before, OffsetDateTime.now());
    }

    static Stream<Arguments> waitForClarificationCases() {
        return Stream.of(
                Arguments.of("ровно 12 ч с создания заявки", Duration.ofHours(12), ActionCode.REVIEW_ALLOW),
                Arguments.of("13 ч с создания заявки", Duration.ofHours(13), ActionCode.REVIEW_ALLOW),
                Arguments.of("у заявки REVIEW_DENY", Duration.ofHours(1), ActionCode.REVIEW_DENY),
                Arguments.of("у заявки ALLOW (без REVIEW)", Duration.ofHours(1), ActionCode.ALLOW),
                Arguments.of("у заявки нет spm_action_code", Duration.ofHours(1), null)
        );
    }

    /**
     * Сейчас падает: в onReview выставляется CashoutStatusCode.CONTROL_SAVOBSK, а по аналитике CONTROL_SPM.
     * Шедулер уточнённой резолюции выбирает РКО по status_code = CONTROL_SPM и такие РКО не увидит.
     */
    @ParameterizedTest(name = "{0}")
    @MethodSource("waitForClarificationCases")
    @DisplayName("Иначе: CONTROL_SPM без субстатуса, дедлайн +2 ч, SPM_CHECK_2, сохранение; конец сценария")
    void waitForClarification(String caseName, Duration sinceApplication, ActionCode applicationSpmActionCode) {
        givenReview(sinceApplication, applicationSpmActionCode);

        SpmOutcome outcome = handler.onReview(cashout);

        assertThat(outcome).isEqualTo(SpmOutcome.STOP);
        InOrder order = inOrder(cashout, actions, cashoutRepository);
        order.verify(cashout).setStatusCode(CashoutStatusCode.CONTROL_SPM);
        order.verify(cashout).setSubStatusCode(null);
        order.verify(cashout).setSpmDeadline(NOW.plusHours(2));
        order.verify(actions).setNotification(cashout, CashoutNotificationCode.SPM_CHECK_2);
        order.verify(cashoutRepository).saveAndFlush(cashout);
        verify(cashout, never()).setSpmActionCode(any());
        verify(actions, never()).createControllerTask(any());
        verifyNoInteractions(activityNotifier);
    }

    @Test
    @DisplayName("Непредусмотренная: задача на контролера, затем EXECUTE сразу")
    void unexpected() {
        SpmOutcome outcome = handler.onUnexpected(cashout);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        InOrder order = inOrder(actions, activityNotifier);
        order.verify(actions).createControllerTask(cashout);
        order.verify(activityNotifier).execute(cashout, "Получена непредусмотренная резолюция");
    }

    @Test
    @DisplayName("Недоступность СПМ: задача на контролера без update/activity")
    void techChallenge() {
        SpmOutcome outcome = handler.onTechChallenge(cashout);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        verify(actions).createControllerTask(cashout);
        verifyNoInteractions(activityNotifier);
    }

    /**
     * spm_action_timestamp РКО = NOW (его проставляет процессор перед onReview),
     * заявка создана sinceApplication назад.
     */
    private void givenReview(Duration sinceApplication, ActionCode applicationSpmActionCode) {
        Application application = mock(Application.class);
        when(application.getCreatedTimestamp()).thenReturn(createdTimestamp(NOW.toInstant().minus(sinceApplication)));
        // при >= 12 ч до проверки кода заявки не доходит (&& короткозамкнутое) — стаб может не понадобиться
        lenient().when(application.getSpmActionCode()).thenReturn(applicationSpmActionCode);
        when(cashout.getApplication()).thenReturn(application);
        when(cashout.getSpmActionTimestamp()).thenReturn(NOW);
    }

    /** TODO тип Application.createdTimestamp: здесь ZonedDateTime; если другой (Timestamp, OffsetDateTime) — поправьте только тут. */
    private static ZonedDateTime createdTimestamp(Instant createdAt) {
        return ZonedDateTime.ofInstant(createdAt, ZoneOffset.UTC);
    }
}
