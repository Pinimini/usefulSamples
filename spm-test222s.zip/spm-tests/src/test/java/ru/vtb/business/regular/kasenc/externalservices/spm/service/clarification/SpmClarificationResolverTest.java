package ru.vtb.business.regular.kasenc.externalservices.spm.service.clarification;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
// TODO поправьте пакет GetObjectStatusDto под свой проект
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.objectstatus.GetObjectStatusDto;

/**
 * Таблица "если http-код = 200" уточнённой резолюции — одинакова для заявки, РКО и ОВН.
 * NO_ANSWER — резолюции нет, процессор переходит к проверке spm_deadline.
 */
class SpmClarificationResolverTest {

    @ParameterizedTest(name = "actionCode={0} -> {1}")
    @CsvSource(nullValues = "NULL", value = {
            "ALLOW,     ALLOW",
            "DENY,      DENY",
            // "<> ('ALLOW' или 'DENY')": REVIEW в аналитике вычеркнут из исключений
            "REVIEW,    UNEXPECTED",
            "CHALLENGE, UNEXPECTED",
            "allow,     UNEXPECTED",   // регистр важен
            "OTHER,     UNEXPECTED",
            "NULL,      NO_ANSWER",
            "'',        NO_ANSWER",
            "'   ',     NO_ANSWER",
    })
    void resolveByCode(String actionCode, String expected) {
        Optional<SpmClarification> actual = SpmClarificationResolver.resolve(actionCode);

        assertThat(actual.map(Enum::name).orElse("NO_ANSWER")).isEqualTo(expected);
    }

    @Test
    @DisplayName("Код берётся из sendResultRequest.actionCode ответа object_status")
    void resolveFromResponse() {
        GetObjectStatusDto response = mock(GetObjectStatusDto.class);
        when(response.getSendResultRequestActionCode()).thenReturn("DENY");

        assertThat(SpmClarificationResolver.resolve(response)).contains(SpmClarification.DENY);
    }

    @Test
    @DisplayName("Пустой ответ -> резолюции нет")
    void nullResponse() {
        assertThat(SpmClarificationResolver.resolve((GetObjectStatusDto) null)).isEmpty();
    }
}
