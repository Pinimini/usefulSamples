package ru.vtb.business.regular.kasenc.externalservices.spm.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.business.regular.kasenc.externalservices.savobsk.dto.activityengineservice.Resolution;
import ru.vtb.business.regular.kasenc.externalservices.savobsk.dto.activityengineservice.UpdateType;
import ru.vtb.business.regular.kasenc.externalservices.spm.TestSpmDocument;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.updateactivity.request.SpmUpdActRequestBody;
// TODO поправьте пакеты клиента и ActionCode под свой проект
import ru.vtb.business.regular.kasenc.externalservices.spm.client.CheckFraudLegalClient;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.response.ActionCode;

@ExtendWith(MockitoExtension.class)
class SpmActivityNotifierTest {

    private static final String DESCRIPTION = "Получена непредусмотренная резолюция";

    @Mock
    private CheckFraudLegalClient checkFraudClient;

    @InjectMocks
    private SpmActivityNotifier notifier;

    @Captor
    private ArgumentCaptor<SpmUpdActRequestBody> requestCaptor;

    private TestSpmDocument document;

    @BeforeEach
    void setUp() {
        document = new TestSpmDocument();
    }

    @Test
    @DisplayName("execute: POST update/activity с EXECUTE, resolution=UNKNOWN и описанием")
    void execute() {
        notifier.execute(document, DESCRIPTION);

        SpmUpdActRequestBody request = sentRequest();
        assertThat(request.getMessageHeader().getUpdateType()).isEqualTo(UpdateType.EXECUTE);
        assertThat(request.getUpdateStatus().getResolution()).isEqualTo(Resolution.UNKNOWN);
        assertThat(request.getUpdateStatus().getDescription()).isEqualTo(DESCRIPTION);
        assertThat(request.getUpdateStatus().getActionSubCode()).isNull();
    }

    /**
     * По аналитике CANCEL нужен и при AUTO_ALLOW: непредусмотренная резолюция -> задача ФРКК не создана ->
     * update/activity CANCEL "Получена непредусмотренная резолюция. Операция отменена по техническим причинам".
     */
    @ParameterizedTest(name = "spm_action_code = {0}")
    @EnumSource(value = ActionCode.class, names = {"ALLOW", "AUTO_ALLOW", "REVIEW_ALLOW", "REVIEW_AUTO_DENY"})
    @DisplayName("cancel: POST update/activity с CANCEL")
    void cancel(ActionCode spmActionCode) {
        document.setSpmActionCode(spmActionCode);

        notifier.cancel(document, DESCRIPTION);

        SpmUpdActRequestBody request = sentRequest();
        assertThat(request.getMessageHeader().getUpdateType()).isEqualTo(UpdateType.CANCEL);
        assertThat(request.getUpdateStatus().getResolution()).isEqualTo(Resolution.UNKNOWN);
        assertThat(request.getUpdateStatus().getDescription()).isEqualTo(DESCRIPTION);
    }

    /**
     * Сейчас падает с NullPointerException: в условии cancel при spmActionCode == null
     * вычисляется вторая часть "|| !document.getSpmActionCode().name()...".
     */
    @Test
    @DisplayName("cancel: документ без spm_action_code не роняет отправку")
    void cancelWithoutActionCode() {
        assertThatCode(() -> notifier.cancel(document, DESCRIPTION)).doesNotThrowAnyException();

        assertThat(sentRequest().getMessageHeader().getUpdateType()).isEqualTo(UpdateType.CANCEL);
    }

    @Test
    @DisplayName("mapToUpdateActivity: заполняет тип, resolution=UNKNOWN, описание и подкод")
    void mapToUpdateActivity() {
        SpmUpdActRequestBody request = notifier.mapToUpdateActivity(UpdateType.CANCEL, DESCRIPTION, "AML");

        assertThat(request.getMessageHeader().getUpdateType()).isEqualTo(UpdateType.CANCEL);
        assertThat(request.getUpdateStatus().getResolution()).isEqualTo(Resolution.UNKNOWN);
        assertThat(request.getUpdateStatus().getDescription()).isEqualTo(DESCRIPTION);
        assertThat(request.getUpdateStatus().getActionSubCode()).isEqualTo("AML");
    }

    private SpmUpdActRequestBody sentRequest() {
        verify(checkFraudClient).updateActivity(requestCaptor.capture(), eq(TestSpmDocument.PRODUCT_TYPE), eq(document.getId()));
        return requestCaptor.getValue();
    }
}
