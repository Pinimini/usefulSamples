package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.business.regular.kasenc.bankcash.mapper.SpmMapper;
import ru.vtb.business.regular.kasenc.bankcash.service.FRKKTaskService;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmOutcome;
import ru.vtb.business.regular.kasenc.externalservices.spm.service.SpmActivityNotifier;
// TODO поправьте пакеты под свой проект
import ru.vtb.business.regular.kasenc.bankcash.domain.Application;
import ru.vtb.business.regular.kasenc.bankcash.domain.ApplicationBankStatusCode;
import ru.vtb.business.regular.kasenc.bankcash.domain.ApplicationBankSubstatusCode;
import ru.vtb.business.regular.kasenc.bankcash.domain.ApplicationNotificationCode;
import ru.vtb.business.regular.kasenc.bankcash.repository.ApplicationRepository;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.request.SpmAnalyzeRequest;

/**
 * Реакции заявки на первичную резолюцию (страница "Интеграция client-cash с bank-cash").
 */
@ExtendWith(MockitoExtension.class)
class ApplicationSpmHandlerTest {

    @Mock
    private FRKKTaskService frkkTaskService;
    @Mock
    private ApplicationRepository applicationRepository;
    @Mock
    private ApplicationStatusUpdater statusUpdater;
    @Mock
    private SpmDeadlineCalculator deadlineCalculator;
    @Mock
    private SpmActivityNotifier activityNotifier;
    @Mock
    private SpmMapper spmMapper;
    @Mock
    private ApplicationFrkkTaskLauncher frkkTaskLauncher;

    @InjectMocks
    private ApplicationSpmHandler handler;

    private Application application;

    @BeforeEach
    void setUp() {
        application = mock(Application.class);
    }

    @Test
    void documentType() {
        assertThat(handler.documentType()).isEqualTo("APPLICATION");
    }

    @Test
    @DisplayName("Запрос analyze строит SpmMapper")
    void buildAnalyzeRequest() {
        SpmAnalyzeRequest request = mock(SpmAnalyzeRequest.class);
        when(spmMapper.mapApplicationToSpmAnalyzeRequest(application)).thenReturn(request);

        assertThat(handler.buildAnalyzeRequest(application)).isSameAs(request);
    }

    /**
     * Сейчас падает: onAllow вызывает и приватный createFrkkTask(...), и frkkTaskLauncher.launch(...) —
     * задача в ФРКК создаётся дважды.
     */
    @Test
    @DisplayName("ALLOW: одна задача в ФРКК, CANCEL \"Операция отменена\" только при ошибке, без EXECUTE")
    void allow() {
        SpmOutcome outcome = handler.onAllow(application);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        verify(frkkTaskLauncher).launch(application, null, "Операция отменена");
        verify(frkkTaskService, never()).sendApplicationProcessingTask(any(), any(), any());
        verifyNoInteractions(statusUpdater);
    }

    @Test
    @DisplayName("DENY: нотификация DENIED_SPM проставлена до смены статуса (иначе не попадёт в save)")
    void deny() {
        SpmOutcome outcome = handler.onDeny(application);

        assertThat(outcome).isEqualTo(SpmOutcome.STOP);
        InOrder order = inOrder(application, statusUpdater);
        order.verify(application).setApplicationNotificationCode(ApplicationNotificationCode.DENIED_SPM);
        order.verify(statusUpdater).update(application,
                ApplicationBankStatusCode.DECLINED, ApplicationBankSubstatusCode.DENIED_SPM, "");
        verifyNoInteractions(frkkTaskLauncher);
    }

    @Test
    @DisplayName("REVIEW: сначала дедлайн и нотификация, потом CONTROL_SPM без субстатуса и отправка в client-cash")
    void review() {
        SpmOutcome outcome = handler.onReview(application);

        assertThat(outcome).isEqualTo(SpmOutcome.STOP);
        InOrder order = inOrder(deadlineCalculator, statusUpdater);
        order.verify(deadlineCalculator).apply(application);
        order.verify(statusUpdater).update(application, ApplicationBankStatusCode.CONTROL_SPM, null, "");
        verifyNoInteractions(frkkTaskLauncher);
    }

    @Test
    @DisplayName("Непредусмотренная: задача в ФРКК с EXECUTE при успехе и CANCEL при ошибке")
    void unexpected() {
        SpmOutcome outcome = handler.onUnexpected(application);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        verify(frkkTaskLauncher).launch(application,
                "Получена непредусмотренная резолюция",
                "Получена непредусмотренная резолюция. Операция отменена по техническим причинам");
        verifyNoInteractions(statusUpdater);
    }

    @Test
    @DisplayName("Недоступность СПМ: задача в ФРКК без update/activity")
    void techChallenge() {
        SpmOutcome outcome = handler.onTechChallenge(application);

        assertThat(outcome).isEqualTo(SpmOutcome.PROCEED);
        verify(frkkTaskLauncher).launch(application, null, null);
        verifyNoInteractions(statusUpdater);
    }
}
