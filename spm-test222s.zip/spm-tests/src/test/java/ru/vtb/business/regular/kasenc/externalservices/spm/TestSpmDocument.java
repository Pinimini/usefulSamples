package ru.vtb.business.regular.kasenc.externalservices.spm;

import java.time.OffsetDateTime;
import java.util.UUID;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmDocument;
// TODO поправьте пакет ActionCode под свой проект
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.response.ActionCode;

/**
 * Документ для тестов процессоров СПМ: только поля из SpmDocument, без JPA.
 */
public class TestSpmDocument implements SpmDocument {

    public static final String PRODUCT_TYPE = "CASHWITHOUTCHECK";

    public enum ProductType { CASHWITHOUTCHECK }

    private final UUID id = UUID.randomUUID();
    private ActionCode spmActionCode;
    private OffsetDateTime spmActionTimestamp;
    private OffsetDateTime spmDeadline;

    public static TestSpmDocument withDeadline(OffsetDateTime spmDeadline) {
        TestSpmDocument document = new TestSpmDocument();
        document.spmDeadline = spmDeadline;
        return document;
    }

    @Override
    public UUID getId() {
        return id;
    }

    @Override
    public Enum<?> getProductTypeCode() {
        return ProductType.CASHWITHOUTCHECK;
    }

    @Override
    public void setSpmActionCode(ActionCode spmActionCode) {
        this.spmActionCode = spmActionCode;
    }

    @Override
    public ActionCode getSpmActionCode() {
        return spmActionCode;
    }

    @Override
    public void setSpmActionTimestamp(OffsetDateTime spmActionTimestamp) {
        this.spmActionTimestamp = spmActionTimestamp;
    }

    public OffsetDateTime getSpmActionTimestamp() {
        return spmActionTimestamp;
    }

    @Override
    public OffsetDateTime getSpmDeadline() {
        return spmDeadline;
    }
}
