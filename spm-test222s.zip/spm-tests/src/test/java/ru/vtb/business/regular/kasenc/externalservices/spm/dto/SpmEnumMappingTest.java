package ru.vtb.business.regular.kasenc.externalservices.spm.dto;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import ru.vtb.business.regular.kasenc.externalservices.spm.service.clarification.SpmClarification;
// TODO поправьте пакет ActionCode под свой проект
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.response.ActionCode;

/**
 * Значения из аналитики, зашитые в enum'ы: имена метрик, spm_action_code, тексты send_result_response.
 * Защищают от случайной правки строк — метрики на дашбордах завязаны на точные имена.
 */
class SpmEnumMappingTest {

    @Nested
    @DisplayName("SpmResolution: метрика и spm_action_code первичной проверки")
    class SpmResolutionMapping {

        @ParameterizedTest(name = "{0} -> {1}, {2}")
        @CsvSource({
                "ALLOW,          cash_bank_cash_analyze_success_allow,       ALLOW",
                "DENY,           cash_bank_cash_analyze_success_deny,        DENY",
                "REVIEW,         cash_bank_cash_analyze_success_review,      REVIEW",
                "UNEXPECTED,     cash_bank_cash_analyze_fail_unexpected,     AUTO_ALLOW",
                "TECH_CHALLENGE, cash_bank_cash_analyze_fail_tech_challenge, AUTO_ALLOW",
        })
        void mapping(SpmResolution resolution, String metricName, ActionCode spmActionCode) {
            assertThat(resolution.getMetricName()).isEqualTo(metricName);
            assertThat(resolution.getSpmActionCode()).isEqualTo(spmActionCode);
        }
    }

    @Nested
    @DisplayName("SpmClarification: spm_action_code и метрика уточнённой резолюции")
    class SpmClarificationMapping {

        @ParameterizedTest(name = "{0} -> {1}, метрика {2}")
        @CsvSource({
                "ALLOW,      REVIEW_ALLOW,      ALLOW",
                "DENY,       REVIEW_DENY,       DENY",
                "UNEXPECTED, REVIEW_AUTO_ALLOW, UNEXPECTED",
        })
        void mapping(SpmClarification clarification, ActionCode spmActionCode, SpmResolution metric) {
            assertThat(clarification.getSpmActionCode()).isEqualTo(spmActionCode);
            assertThat(clarification.getMetric()).isEqualTo(metric);
        }
    }

    @Nested
    @DisplayName("SpmExpiryPolicy: решение по умолчанию после spm_deadline")
    class SpmExpiryPolicyMapping {

        @ParameterizedTest(name = "{0} -> {1}")
        @CsvSource(delimiter = '|', value = {
                "AUTO_ALLOW | REVIEW_AUTO_ALLOW | Время ожидания REVIEW истекло. Операция продолжена",
                "AUTO_DENY  | REVIEW_AUTO_DENY  | Время ожидания REVIEW истекло. Операция отменена",
        })
        void mapping(SpmExpiryPolicy policy, ActionCode spmActionCode, String sendResultDescription) {
            assertThat(policy.getSpmActionCode()).isEqualTo(spmActionCode);
            assertThat(policy.getSendResultDescription()).isEqualTo(sendResultDescription);
        }
    }
}
