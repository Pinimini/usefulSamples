package ru.vtb.business.regular.kasenc.externalservices.spm.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmOutcome;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmResolution;

class SpmCheckResultTest {

    @ParameterizedTest(name = "{0} -> proceed() = {1}")
    @CsvSource({
            "PROCEED, true",
            "STOP,    false",
    })
    void proceed(SpmOutcome outcome, boolean expected) {
        assertThat(new SpmCheckResult(SpmResolution.ALLOW, outcome).proceed()).isEqualTo(expected);
    }
}
