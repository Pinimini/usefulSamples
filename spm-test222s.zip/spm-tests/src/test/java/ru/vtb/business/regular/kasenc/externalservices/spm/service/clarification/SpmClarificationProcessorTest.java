package ru.vtb.business.regular.kasenc.externalservices.spm.service.clarification;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;
import ru.vtb.business.regular.kasenc.externalservices.spm.TestSpmDocument;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmExpiryPolicy;
// TODO поправьте пакеты клиента и DTO под свой проект
import ru.vtb.business.regular.kasenc.externalservices.spm.client.CheckFraudLegalClient;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.response.ActionCode;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.objectstatus.GetObjectStatusDto;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.sendresult.SpmSendResultActionCode;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.sendresult.SpmSendResultErrorCode;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.sendresult.SpmSendResultRequest;

/**
 * Предполагаемые сигнатуры клиента (как analyze/updateActivity без authHeader):
 * getObjectStatusDto(productType, id), sendResultResponse(request, productType, id).
 * Если у вас другие — поправьте вызовы в givenObjectStatus / sentResult.
 */
@ExtendWith(MockitoExtension.class)
class SpmClarificationProcessorTest {

    private static final OffsetDateTime NOW = OffsetDateTime.of(2026, 10, 11, 12, 0, 0, 0, ZoneOffset.UTC);
    private static final OffsetDateTime DEADLINE_AHEAD = NOW.plusHours(1);
    private static final OffsetDateTime DEADLINE_PASSED = NOW.minusMinutes(1);

    @Mock
    private CheckFraudLegalClient checkFraudClient;

    @Mock
    private SpmClarificationHandler<TestSpmDocument> handler;

    @Captor
    private ArgumentCaptor<SpmSendResultRequest> sendResultCaptor;

    private SpmClarificationProcessor processor;

    @BeforeEach
    void setUp() {
        processor = new SpmClarificationProcessor(checkFraudClient, List.of(handler));
        lenient().when(handler.documentType()).thenReturn("TEST");
    }

    @Nested
    @DisplayName("Уточнённая резолюция получена")
    class ResolutionReceived {

        @Test
        @DisplayName("ALLOW: send_result SUCCESS/ALLOW, REVIEW_ALLOW, onAllow")
        void allow() {
            TestSpmDocument document = TestSpmDocument.withDeadline(DEADLINE_AHEAD);
            givenObjectStatus(document, "ALLOW");

            processor.clarify(document, handler, NOW);

            SpmSendResultRequest sent = sentResult(document);
            assertThat(sent.getErrorCode()).isEqualTo(SpmSendResultErrorCode.SUCCESS);
            assertThat(sent.getActionCode()).isEqualTo(SpmSendResultActionCode.ALLOW);
            assertThat(document.getSpmActionCode()).isEqualTo(ActionCode.REVIEW_ALLOW);
            assertThat(document.getSpmActionTimestamp()).isNotNull();
            verify(handler).onAllow(document);
            verifyNoOtherReaction(document, "onAllow");
        }

        @Test
        @DisplayName("DENY: send_result SUCCESS/DENY, REVIEW_DENY, onDeny")
        void deny() {
            TestSpmDocument document = TestSpmDocument.withDeadline(DEADLINE_AHEAD);
            givenObjectStatus(document, "DENY");

            processor.clarify(document, handler, NOW);

            SpmSendResultRequest sent = sentResult(document);
            assertThat(sent.getErrorCode()).isEqualTo(SpmSendResultErrorCode.SUCCESS);
            assertThat(sent.getActionCode()).isEqualTo(SpmSendResultActionCode.DENY);
            assertThat(document.getSpmActionCode()).isEqualTo(ActionCode.REVIEW_DENY);
            verify(handler).onDeny(document);
            verifyNoOtherReaction(document, "onDeny");
        }

        @ParameterizedTest(name = "actionCode = {0}")
        @ValueSource(strings = {"REVIEW", "CHALLENGE", "OTHER"})
        @DisplayName("Непредусмотренная: send_result FAIL с описанием, REVIEW_AUTO_ALLOW, onUnexpected")
        void unexpected(String actionCode) {
            TestSpmDocument document = TestSpmDocument.withDeadline(DEADLINE_AHEAD);
            givenObjectStatus(document, actionCode);

            processor.clarify(document, handler, NOW);

            SpmSendResultRequest sent = sentResult(document);
            assertThat(sent.getErrorCode()).isEqualTo(SpmSendResultErrorCode.FAIL);
            assertThat(sent.getErrorDescription()).isEqualTo(SpmClarificationProcessor.UNEXPECTED_DESCRIPTION);
            assertThat(document.getSpmActionCode()).isEqualTo(ActionCode.REVIEW_AUTO_ALLOW);
            verify(handler).onUnexpected(document);
            verifyNoOtherReaction(document, "onUnexpected");
        }

        @Test
        @DisplayName("Резолюция есть — дедлайн не проверяется, даже если истёк")
        void resolutionWinsOverExpiredDeadline() {
            TestSpmDocument document = TestSpmDocument.withDeadline(DEADLINE_PASSED);
            givenObjectStatus(document, "ALLOW");

            processor.clarify(document, handler, NOW);

            verify(handler).onAllow(document);
            verify(handler, never()).expiryPolicy();
            verify(handler, never()).onDeadlineExpired(any());
        }

        @Test
        @DisplayName("send_result упал — документ не меняется и обработчик не вызывается (повтор при следующем запуске)")
        void sendResultFailureLeavesDocumentUntouched() {
            TestSpmDocument document = TestSpmDocument.withDeadline(DEADLINE_AHEAD);
            givenObjectStatus(document, "ALLOW");
            doThrow(new HttpServerErrorException(HttpStatus.BAD_GATEWAY))
                    .when(checkFraudClient).sendResultResponse(any(), any(), any());

            processor.clarifyAll(singleDocumentHandler(document), NOW);

            assertThat(document.getSpmActionCode()).isNull();
            verify(handler, never()).onAllow(any());
        }
    }

    @Nested
    @DisplayName("Уточнённой резолюции нет")
    class NoResolution {

        @ParameterizedTest(name = "actionCode = \"{0}\"")
        @NullAndEmptySource
        @ValueSource(strings = "   ")
        @DisplayName("Дедлайн не истёк — ждём: ничего не отправляем и не меняем")
        void waitsUntilDeadline(String actionCode) {
            TestSpmDocument document = TestSpmDocument.withDeadline(DEADLINE_AHEAD);
            givenObjectStatus(document, actionCode);

            processor.clarify(document, handler, NOW);

            verify(checkFraudClient, never()).sendResultResponse(any(), any(), any());
            assertThat(document.getSpmActionCode()).isNull();
            verifyNoOtherReaction(document, null);
        }

        @Test
        @DisplayName("Дедлайн ровно сейчас — ещё не истёк")
        void deadlineEqualToNowIsNotExpired() {
            TestSpmDocument document = TestSpmDocument.withDeadline(NOW);
            givenObjectStatus(document, null);

            processor.clarify(document, handler, NOW);

            verify(handler, never()).onDeadlineExpired(any());
        }

        @ParameterizedTest(name = "{0}")
        @EnumSource(SpmExpiryPolicy.class)
        @DisplayName("Дедлайн истёк — решение по умолчанию из политики обработчика")
        void deadlineExpired(SpmExpiryPolicy policy) {
            TestSpmDocument document = TestSpmDocument.withDeadline(DEADLINE_PASSED);
            givenObjectStatus(document, null);
            when(handler.expiryPolicy()).thenReturn(policy);

            processor.clarify(document, handler, NOW);

            SpmSendResultRequest sent = sentResult(document);
            assertThat(sent.getErrorCode()).isEqualTo(SpmSendResultErrorCode.FAIL);
            assertThat(sent.getErrorDescription()).isEqualTo(policy.getSendResultDescription());
            assertThat(document.getSpmActionCode()).isEqualTo(policy.getSpmActionCode());
            verify(handler).onDeadlineExpired(document);
            verifyNoOtherReaction(document, "onDeadlineExpired");
        }

        @Test
        @DisplayName("object_status вернул ошибку и дедлайн истёк — решение по умолчанию")
        void objectStatusErrorThenDeadlineExpired() {
            TestSpmDocument document = TestSpmDocument.withDeadline(DEADLINE_PASSED);
            when(checkFraudClient.getObjectStatusDto(TestSpmDocument.PRODUCT_TYPE, document.getId()))
                    .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));
            when(handler.expiryPolicy()).thenReturn(SpmExpiryPolicy.AUTO_DENY);

            processor.clarify(document, handler, NOW);

            assertThat(document.getSpmActionCode()).isEqualTo(ActionCode.REVIEW_AUTO_DENY);
            verify(handler).onDeadlineExpired(document);
        }

        @Test
        @DisplayName("object_status вернул ошибку, дедлайн не истёк — ждём")
        void objectStatusErrorBeforeDeadline() {
            TestSpmDocument document = TestSpmDocument.withDeadline(DEADLINE_AHEAD);
            when(checkFraudClient.getObjectStatusDto(TestSpmDocument.PRODUCT_TYPE, document.getId()))
                    .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

            processor.clarify(document, handler, NOW);

            verify(checkFraudClient, never()).sendResultResponse(any(), any(), any());
            verifyNoOtherReaction(document, null);
        }

        @Test
        @DisplayName("Нет spm_deadline — решение по умолчанию не применяется")
        void noDeadline() {
            TestSpmDocument document = TestSpmDocument.withDeadline(null);
            givenObjectStatus(document, null);

            processor.clarify(document, handler, NOW);

            verify(checkFraudClient, never()).sendResultResponse(any(), any(), any());
            verifyNoOtherReaction(document, null);
        }
    }

    @Nested
    @DisplayName("Цикл по документам и обработчикам")
    class Loop {

        @Test
        @DisplayName("Ошибка по одному документу не останавливает остальные")
        void continuesAfterDocumentFailure() {
            TestSpmDocument failing = TestSpmDocument.withDeadline(DEADLINE_AHEAD);
            TestSpmDocument next = TestSpmDocument.withDeadline(DEADLINE_AHEAD);
            givenObjectStatus(failing, "ALLOW");
            givenObjectStatus(next, "DENY");
            doThrow(new IllegalStateException("db down")).when(handler).onAllow(failing);
            when(handler.findAwaitingClarification()).thenReturn(List.of(failing, next));

            processor.clarifyAll(handler, NOW);

            verify(handler).onDeny(next);
            assertThat(next.getSpmActionCode()).isEqualTo(ActionCode.REVIEW_DENY);
        }

        @Test
        @DisplayName("Выключенный рубильник — документы не выбираются")
        void skipsDisabledHandler() {
            when(handler.isEnabled()).thenReturn(false);

            processor.run(NOW);

            verify(handler, never()).findAwaitingClarification();
            verify(checkFraudClient, never()).getObjectStatusDto(any(), any());
        }

        @Test
        @DisplayName("Обработчики вызываются в порядке списка (@Order), выключенный пропускается")
        void runsHandlersInOrder() {
            @SuppressWarnings("unchecked")
            SpmClarificationHandler<TestSpmDocument> disabled = mock(SpmClarificationHandler.class);
            @SuppressWarnings("unchecked")
            SpmClarificationHandler<TestSpmDocument> second = mock(SpmClarificationHandler.class);
            lenient().when(disabled.documentType()).thenReturn("DISABLED");
            lenient().when(second.documentType()).thenReturn("SECOND");
            when(handler.isEnabled()).thenReturn(true);
            when(disabled.isEnabled()).thenReturn(false);
            when(second.isEnabled()).thenReturn(true);
            when(handler.findAwaitingClarification()).thenReturn(List.of());
            when(second.findAwaitingClarification()).thenReturn(List.of());

            new SpmClarificationProcessor(checkFraudClient, List.of(handler, disabled, second)).run(NOW);

            InOrder order = inOrder(handler, second);
            order.verify(handler).findAwaitingClarification();
            order.verify(second).findAwaitingClarification();
            verify(disabled, never()).findAwaitingClarification();
        }
    }

    // ------------------------------------------------------------------------------------

    private void givenObjectStatus(TestSpmDocument document, String actionCode) {
        GetObjectStatusDto response = mock(GetObjectStatusDto.class);
        when(response.getSendResultRequestActionCode()).thenReturn(actionCode);
        when(checkFraudClient.getObjectStatusDto(TestSpmDocument.PRODUCT_TYPE, document.getId())).thenReturn(response);
    }

    private SpmSendResultRequest sentResult(TestSpmDocument document) {
        verify(checkFraudClient).sendResultResponse(sendResultCaptor.capture(),
                eq(TestSpmDocument.PRODUCT_TYPE), eq(document.getId()));
        return sendResultCaptor.getValue();
    }

    private SpmClarificationHandler<TestSpmDocument> singleDocumentHandler(TestSpmDocument document) {
        when(handler.findAwaitingClarification()).thenReturn(List.of(document));
        return handler;
    }

    /** Проверяет, что кроме expected (или ни одна, если null) другие реакции обработчика не вызывались. */
    private void verifyNoOtherReaction(TestSpmDocument document, String expected) {
        if (!"onAllow".equals(expected)) {
            verify(handler, never()).onAllow(document);
        }
        if (!"onDeny".equals(expected)) {
            verify(handler, never()).onDeny(document);
        }
        if (!"onUnexpected".equals(expected)) {
            verify(handler, never()).onUnexpected(document);
        }
        if (!"onDeadlineExpired".equals(expected)) {
            verify(handler, never()).onDeadlineExpired(document);
        }
    }
}
