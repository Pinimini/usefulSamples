package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.business.regular.kasenc.bankcash.service.FRKKTaskService;
import ru.vtb.business.regular.kasenc.externalservices.spm.service.SpmActivityNotifier;
// TODO поправьте пакеты под свой проект
import ru.vtb.business.regular.kasenc.bankcash.domain.Application;
import ru.vtb.business.regular.kasenc.bankcash.domain.ApplicationBankStatusCode;
import ru.vtb.business.regular.kasenc.bankcash.domain.ApplicationBankSubstatusCode;
import ru.vtb.business.regular.kasenc.bankcash.domain.ApplicationNotificationCode;
import ru.vtb.business.regular.kasenc.bankcash.repository.ApplicationRepository;

/**
 * "Создать задачу в ФРКК на обработку заявки" и реакция на результат.
 * Обработчики заявки этот класс мокают, поэтому логика колбэков проверяется здесь.
 *
 * TODO тип колбэков в FRKKTaskService.sendApplicationProcessingTask — здесь Consumer<UUID>;
 *  если у вас свой функциональный интерфейс, поменяйте тип в @Captor.
 */
@ExtendWith(MockitoExtension.class)
class ApplicationFrkkTaskLauncherTest {

    private static final UUID APPLICATION_ID = UUID.randomUUID();
    private static final String EXECUTE_TEXT = "Получена непредусмотренная резолюция";
    private static final String CANCEL_TEXT = "Операция отменена";

    @Mock
    private FRKKTaskService frkkTaskService;
    @Mock
    private ApplicationRepository applicationRepository;
    @Mock
    private ApplicationStatusUpdater statusUpdater;
    @Mock
    private SpmActivityNotifier activityNotifier;

    @InjectMocks
    private ApplicationFrkkTaskLauncher launcher;

    @Captor
    private ArgumentCaptor<Consumer<UUID>> onCreated;
    @Captor
    private ArgumentCaptor<Consumer<UUID>> onFailed;

    private Application application;

    @BeforeEach
    void setUp() {
        application = mock(Application.class);
    }

    @Test
    @DisplayName("Заявка сохраняется до отправки задачи — колбэки перечитывают её из БД")
    void savesBeforeSendingTask() {
        launcher.launch(application, null, null);

        InOrder order = inOrder(applicationRepository, frkkTaskService);
        order.verify(applicationRepository).saveAndFlush(application);
        order.verify(frkkTaskService).sendApplicationProcessingTask(any(), any(), any());
    }

    @Nested
    @DisplayName("Задача создана")
    class TaskCreated {

        @Test
        @DisplayName("Субстатус UNPROCESSED_TASK_CREATED и EXECUTE с переданным текстом")
        void withExecute() {
            Application reloaded = givenReloadedApplication();

            launchAndCaptureCallbacks(EXECUTE_TEXT, CANCEL_TEXT);
            onCreated.getValue().accept(APPLICATION_ID);

            InOrder order = inOrder(reloaded, applicationRepository, activityNotifier);
            order.verify(reloaded).setBankSubstatusCode(ApplicationBankSubstatusCode.UNPROCESSED_TASK_CREATED);
            order.verify(applicationRepository).saveAndFlush(reloaded);
            order.verify(activityNotifier).execute(reloaded, EXECUTE_TEXT);
            verify(activityNotifier, never()).cancel(any(), any());
            verifyNoInteractions(statusUpdater);
        }

        @Test
        @DisplayName("Без текста EXECUTE — только субстатус (ALLOW, CHALLENGE)")
        void withoutExecute() {
            Application reloaded = givenReloadedApplication();

            launchAndCaptureCallbacks(null, CANCEL_TEXT);
            onCreated.getValue().accept(APPLICATION_ID);

            verify(reloaded).setBankSubstatusCode(ApplicationBankSubstatusCode.UNPROCESSED_TASK_CREATED);
            verifyNoInteractions(activityNotifier);
        }
    }

    @Nested
    @DisplayName("Задача не создана")
    class TaskFailed {

        @Test
        @DisplayName("FRKK_TASK_ERROR до смены статуса, DECLINED / DECLINED_TASK_ERROR, CANCEL с переданным текстом")
        void withCancel() {
            Application reloaded = givenReloadedApplication();

            launchAndCaptureCallbacks(EXECUTE_TEXT, CANCEL_TEXT);
            onFailed.getValue().accept(APPLICATION_ID);

            InOrder order = inOrder(reloaded, statusUpdater, activityNotifier);
            order.verify(reloaded).setApplicationNotificationCode(ApplicationNotificationCode.FRKK_TASK_ERROR);
            order.verify(statusUpdater).update(reloaded,
                    ApplicationBankStatusCode.DECLINED, ApplicationBankSubstatusCode.DECLINED_TASK_ERROR, "");
            order.verify(activityNotifier).cancel(reloaded, CANCEL_TEXT);
            verify(activityNotifier, never()).execute(any(), any());
        }

        @Test
        @DisplayName("Без текста CANCEL — только смена статуса (CHALLENGE)")
        void withoutCancel() {
            Application reloaded = givenReloadedApplication();

            launchAndCaptureCallbacks(null, null);
            onFailed.getValue().accept(APPLICATION_ID);

            verify(statusUpdater).update(reloaded,
                    ApplicationBankStatusCode.DECLINED, ApplicationBankSubstatusCode.DECLINED_TASK_ERROR, "");
            verifyNoInteractions(activityNotifier);
        }
    }

    @Test
    @DisplayName("Заявка не найдена — колбэки ничего не делают")
    void applicationNotFound() {
        when(applicationRepository.findById(APPLICATION_ID)).thenReturn(Optional.empty());

        launchAndCaptureCallbacks(EXECUTE_TEXT, CANCEL_TEXT);
        onCreated.getValue().accept(APPLICATION_ID);
        onFailed.getValue().accept(APPLICATION_ID);

        verify(applicationRepository).saveAndFlush(application); // только сохранение в launch
        verifyNoInteractions(statusUpdater, activityNotifier);
    }

    private Application givenReloadedApplication() {
        Application reloaded = mock(Application.class);
        when(applicationRepository.findById(APPLICATION_ID)).thenReturn(Optional.of(reloaded));
        return reloaded;
    }

    private void launchAndCaptureCallbacks(String executeOnCreated, String cancelOnFailed) {
        launcher.launch(application, executeOnCreated, cancelOnFailed);
        verify(frkkTaskService).sendApplicationProcessingTask(
                eq(application), onCreated.capture(), onFailed.capture());
    }
}
