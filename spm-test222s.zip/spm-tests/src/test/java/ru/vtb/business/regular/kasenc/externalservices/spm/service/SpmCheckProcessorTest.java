package ru.vtb.business.regular.kasenc.externalservices.spm.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import ru.vtb.business.regular.kasenc.externalservices.spm.TestSpmDocument;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmOutcome;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.SpmResolution;
// TODO поправьте пакеты клиента и DTO под свой проект
import ru.vtb.business.regular.kasenc.externalservices.spm.client.CheckFraudLegalClient;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.request.SpmAnalyzeRequest;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.response.ActionCode;
import ru.vtb.business.regular.kasenc.externalservices.spm.dto.checkoperation.response.SpmAnalyzeResponse;

@ExtendWith(MockitoExtension.class)
class SpmCheckProcessorTest {

    @Mock
    private CheckFraudLegalClient checkFraudClient;

    @Mock
    private SpmDocumentHandler<TestSpmDocument> handler;

    @InjectMocks
    private SpmCheckProcessor processor;

    private TestSpmDocument document;
    private SpmAnalyzeRequest request;

    @BeforeEach
    void setUp() {
        document = new TestSpmDocument();
        request = mock(SpmAnalyzeRequest.class);
        lenient().when(handler.documentType()).thenReturn("TEST");
        when(handler.buildAnalyzeRequest(document)).thenReturn(request);
    }

    static Stream<Arguments> resolutions() {
        return Stream.of(
                arguments(ActionCode.ALLOW, null, SpmResolution.ALLOW),
                arguments(ActionCode.DENY, "AML", SpmResolution.DENY),
                arguments(ActionCode.REVIEW, "AML", SpmResolution.REVIEW),
                arguments(ActionCode.DENY, null, SpmResolution.UNEXPECTED),
                arguments(ActionCode.CHALLENGE, null, SpmResolution.TECH_CHALLENGE)
        );
    }

    @ParameterizedTest(name = "{0}/{1} -> {2}")
    @MethodSource("resolutions")
    @DisplayName("Вызывает обработчик своей резолюции и только его")
    void callsHandlerOfResolution(ActionCode actionCode, String actionSubCode, SpmResolution expected) {
        givenAnalyzeResponse(actionCode, actionSubCode);
        when(callHandler(handler, expected, document)).thenReturn(SpmOutcome.STOP);

        SpmCheckResult result = processor.check(document, handler);

        assertThat(result.resolution()).isEqualTo(expected);
        assertThat(result.outcome()).isEqualTo(SpmOutcome.STOP);
        verify(handler).documentType();
        verify(handler).buildAnalyzeRequest(document);
        callHandler(verify(handler), expected, document);
        verifyNoMoreInteractions(handler);
    }

    @ParameterizedTest(name = "{2}")
    @MethodSource("resolutions")
    @DisplayName("До вызова обработчика проставляет spm_action_code и spm_action_timestamp")
    void setsActionCodeAndTimestampBeforeHandler(ActionCode actionCode, String actionSubCode, SpmResolution expected) {
        givenAnalyzeResponse(actionCode, actionSubCode);
        OffsetDateTime before = OffsetDateTime.now();
        when(callHandler(handler, expected, document)).thenAnswer(invocation -> {
            // обработчик уже видит проставленные значения
            assertThat(document.getSpmActionCode()).isEqualTo(expected.getSpmActionCode());
            assertThat(document.getSpmActionTimestamp()).isNotNull();
            return SpmOutcome.PROCEED;
        });

        processor.check(document, handler);

        assertThat(document.getSpmActionCode()).isEqualTo(expected.getSpmActionCode());
        assertThat(document.getSpmActionTimestamp()).isBetween(before, OffsetDateTime.now());
    }

    @Test
    @DisplayName("Передаёт в analyze запрос обработчика, тип продукта и id документа")
    void passesRequestProductTypeAndIdToClient() {
        givenAnalyzeResponse(ActionCode.ALLOW, null);
        when(handler.onAllow(document)).thenReturn(SpmOutcome.PROCEED);

        processor.check(document, handler);

        verify(checkFraudClient).analyze(request, TestSpmDocument.PRODUCT_TYPE, document.getId());
    }

    @Test
    @DisplayName("Возвращает решение обработчика: PROCEED -> proceed() = true")
    void returnsHandlerOutcome() {
        givenAnalyzeResponse(ActionCode.ALLOW, null);
        when(handler.onAllow(document)).thenReturn(SpmOutcome.PROCEED);

        SpmCheckResult result = processor.check(document, handler);

        assertThat(result.outcome()).isEqualTo(SpmOutcome.PROCEED);
        assertThat(result.proceed()).isTrue();
    }

    @Test
    @DisplayName("Пустой ответ check-fraud -> непредусмотренная резолюция")
    void nullResponseIsUnexpected() {
        when(checkFraudClient.analyze(any(), any(), any())).thenReturn(null);
        when(handler.onUnexpected(document)).thenReturn(SpmOutcome.PROCEED);

        SpmCheckResult result = processor.check(document, handler);

        assertThat(result.resolution()).isEqualTo(SpmResolution.UNEXPECTED);
        assertThat(document.getSpmActionCode()).isEqualTo(ActionCode.AUTO_ALLOW);
    }

    static Stream<RestClientException> clientErrors() {
        return Stream.of(
                new ResourceAccessException("timeout"),
                new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR),
                new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT)
        );
    }

    @ParameterizedTest(name = "{0}")
    @MethodSource("clientErrors")
    @DisplayName("Ошибка вызова check-fraud -> резолюция по умолчанию (как CHALLENGE)")
    void clientErrorIsTechChallenge(RestClientException error) {
        when(checkFraudClient.analyze(any(), any(), any())).thenThrow(error);
        when(handler.onTechChallenge(document)).thenReturn(SpmOutcome.PROCEED);

        SpmCheckResult result = processor.check(document, handler);

        assertThat(result.resolution()).isEqualTo(SpmResolution.TECH_CHALLENGE);
        assertThat(result.proceed()).isTrue();
        assertThat(document.getSpmActionCode()).isEqualTo(ActionCode.AUTO_ALLOW);
        verify(handler).onTechChallenge(document);
    }

    @Test
    @DisplayName("Прочие исключения не глотаются: обработчик не вызывается, документ не меняется")
    void otherExceptionsPropagate() {
        when(checkFraudClient.analyze(any(), any(), any())).thenThrow(new IllegalStateException("bug"));

        assertThatThrownBy(() -> processor.check(document, handler)).isInstanceOf(IllegalStateException.class);

        assertThat(document.getSpmActionCode()).isNull();
        verify(handler).documentType();
        verify(handler).buildAnalyzeRequest(document);
        verifyNoMoreInteractions(handler);
    }

    private void givenAnalyzeResponse(ActionCode actionCode, String actionSubCode) {
        SpmAnalyzeResponse response = mock(SpmAnalyzeResponse.class, RETURNS_DEEP_STUBS);
        when(response.getRiskResult().getTriggeredRule().getActionCode()).thenReturn(actionCode);
        when(response.getRiskResult().getTriggeredRule().getActionSubCode()).thenReturn(actionSubCode);
        when(checkFraudClient.analyze(request, TestSpmDocument.PRODUCT_TYPE, document.getId())).thenReturn(response);
    }

    /** Вызов метода обработчика, соответствующего резолюции — для when(...) и verify(...). */
    private static SpmOutcome callHandler(SpmDocumentHandler<TestSpmDocument> handler,
                                          SpmResolution resolution, TestSpmDocument document) {
        return switch (resolution) {
            case ALLOW -> handler.onAllow(document);
            case DENY -> handler.onDeny(document);
            case REVIEW -> handler.onReview(document);
            case UNEXPECTED -> handler.onUnexpected(document);
            case TECH_CHALLENGE -> handler.onTechChallenge(document);
        };
    }
}
