package ru.vtb.business.regular.kasenc.bankcash.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.vtb.business.regular.kasenc.bankcash.service.spm.ApplicationSpmHandler;
import ru.vtb.business.regular.kasenc.bankcash.service.spm.ApplicationStatusUpdater;
import ru.vtb.business.regular.kasenc.spm.SpmCheckProcessor;
// + Application, коды статусов из вашего проекта

/**
 * Фасад для обратной совместимости: вызывающий код не меняется.
 * Когда вызовы перейдут на SpmCheckProcessor / ApplicationStatusUpdater напрямую — класс можно удалить.
 */
@Service
@RequiredArgsConstructor
public class BankCashCheckFraudService {

    private final SpmCheckProcessor spmCheckProcessor;
    private final ApplicationSpmHandler applicationSpmHandler;
    private final ApplicationStatusUpdater applicationStatusUpdater;

    public void checkFraudSpm(Application application) {
        spmCheckProcessor.check(application, applicationSpmHandler);
    }

    /** @deprecated используйте {@link ApplicationStatusUpdater#update} */
    @Deprecated
    public void updateApplicationStatus(Application application,
                                        ApplicationBankStatusCode applicationStatusCode,
                                        ApplicationBankSubstatusCode applicationSubstatusCode,
                                        String statusMessage) {
        applicationStatusUpdater.update(application, applicationStatusCode, applicationSubstatusCode, statusMessage);
    }
}
