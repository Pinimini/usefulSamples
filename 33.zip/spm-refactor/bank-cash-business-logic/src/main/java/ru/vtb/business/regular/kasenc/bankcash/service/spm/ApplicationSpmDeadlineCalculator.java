package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import org.springframework.stereotype.Component;
// + Application, ApplicationNotificationCode из вашего проекта

/**
 * "Определение дедлайна и нотификации по REVIEW для заявки на получение наличных".
 * Выделено отдельно: чистая логика по датам, удобно тестировать без моков.
 */
@Component
public class ApplicationSpmDeadlineCalculator {

    public void apply(Application application) {
        int utcShift = application.getSalePoint().getUtcShift();
        ZoneOffset salePointOffset = ZoneOffset.ofTotalSeconds(utcShift * 3600);

        OffsetDateTime createdUtc = application.getCreatedTimestamp().toInstant()
                .atZone(ZoneOffset.UTC)
                .toOffsetDateTime();
        LocalDate localCreatedDate = createdUtc.withOffsetSameInstant(salePointOffset).toLocalDate();

        // Разница в днях между днём операции и днём создания (в локальном времени ТП)
        long daysDifference = ChronoUnit.DAYS.between(localCreatedDate, application.getOperationDate());

        if (daysDifference == 0) {
            application.setSpmDeadline(createdUtc.plusHours(2));
            application.setApplicationNotificationCode(ApplicationNotificationCode.SPM_CHECK_2);

        } else if (daysDifference == 1) {
            // завтра 08:00 по времени ТП (сверить со страницей дедлайнов)
            LocalDateTime tomorrow0800 = localCreatedDate.plusDays(1).atTime(8, 0);
            application.setSpmDeadline(toUtc(tomorrow0800, salePointOffset));
            application.setApplicationNotificationCode(ApplicationNotificationCode.SPM_CHECK_48);

        } else if (daysDifference == 2) {
            // послезавтра 00:00 по времени ТП (сверить со страницей дедлайнов)
            LocalDateTime dayAfterTomorrow0000 = localCreatedDate.plusDays(2).atStartOfDay();
            application.setSpmDeadline(toUtc(dayAfterTomorrow0000, salePointOffset));
            application.setApplicationNotificationCode(ApplicationNotificationCode.SPM_CHECK_48);

        } else if (daysDifference > 2) {
            application.setSpmDeadline(createdUtc.plusHours(48));
            application.setApplicationNotificationCode(ApplicationNotificationCode.SPM_CHECK_48);
        }
    }

    private static OffsetDateTime toUtc(LocalDateTime local, ZoneOffset offset) {
        return local.atOffset(offset).withOffsetSameInstant(ZoneOffset.UTC);
    }
}
