package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmMetrics;
import ru.vtb.business.regular.kasenc.spm.SpmResolution;
// + BankCashMonitoring из вашего проекта

/**
 * Метрики СПМ через существующий BankCashMonitoring — единственная реализация SpmMetrics в приложении.
 * Если приходные/расходные документы работают в другом приложении, там нужна своя реализация SpmMetrics.
 */
@Component
@RequiredArgsConstructor
public class BankCashSpmMetrics implements SpmMetrics {

    private final BankCashMonitoring bankCashMonitoring;

    @Override
    public void increment(SpmResolution resolution, String documentType) {
        // TODO подставьте реальный метод BankCashMonitoring; documentType можно передать тегом
        bankCashMonitoring.incrementCounter(resolution.getMetricName());
    }
}
