package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
import ru.vtb.business.regular.kasenc.spm.clarification.SpmClarificationHandler;
import ru.vtb.business.regular.kasenc.spm.clarification.SpmExpiryPolicy;
// + Application, ApplicationRepository, коды статусов/нотификаций из вашего проекта

/**
 * Уточнённая резолюция по заявкам — п.3 "Обработка заявок" страницы
 * "Задания по расписанию для проверки уточнённой резолюции". Заменяет BankCashClarifiedResolutionService.
 */
@Order(1)
@Component
@RequiredArgsConstructor
public class ApplicationClarificationHandler implements SpmClarificationHandler<Application> {

    private static final String ALLOW_CANCELLED = "Операция отменена";
    private static final String EXPIRED_EXECUTE = "Истекло время ожидания уточняющей резолюции (технический ALLOW)";
    private static final String EXPIRED_CANCEL =
            "Истекло время ожидания уточняющей резолюции. Операция отменена по техническим причинам";

    private final ApplicationRepository applicationRepository;
    private final ApplicationFrkkTaskLauncher frkkTaskLauncher;
    private final ApplicationStatusUpdater statusUpdater;

    @Value("${SPM_APPLICATION_CHECKSFRAUD_ENABLED:true}")
    private boolean enabled;

    @Override
    public String documentType() {
        return "APPLICATION";
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public List<Application> findAwaitingClarification() {
        return applicationRepository.findAllByBankStatusCode(ApplicationBankStatusCode.CONTROL_SPM);
    }

    @Override
    public SpmExpiryPolicy expiryPolicy() {
        return SpmExpiryPolicy.AUTO_ALLOW;
    }

    /** ALLOW п.5–8. */
    @Override
    public void onAllow(Application application) {
        toUnprocessed(application);
        frkkTaskLauncher.launch(application, null, ALLOW_CANCELLED);
    }

    /** DENY п.5–8. */
    @Override
    public void onDeny(Application application) {
        application.setApplicationNotificationCode(ApplicationNotificationCode.DENIED_SPM);
        statusUpdater.update(application, ApplicationBankStatusCode.DECLINED,
                ApplicationBankSubstatusCode.DENIED_SPM, "");
    }

    /** Непредусмотренная резолюция п.5–8. */
    @Override
    public void onUnexpected(Application application) {
        toUnprocessed(application);
        frkkTaskLauncher.launch(application,
                SpmActivityNotifier.UNEXPECTED_RESOLUTION,
                SpmActivityNotifier.UNEXPECTED_RESOLUTION_CANCELLED);
    }

    /** Шаг iii, C–G: технический ALLOW. */
    @Override
    public void onDeadlineExpired(Application application) {
        toUnprocessed(application);
        frkkTaskLauncher.launch(application, EXPIRED_EXECUTE, EXPIRED_CANCEL);
    }

    private static void toUnprocessed(Application application) {
        application.setBankStatusCode(ApplicationBankStatusCode.UNPROCESSED);
        application.setBankSubstatusCode(ApplicationBankSubstatusCode.UNPROCESSED_SAVED);
        application.setApplicationNotificationCode(null);
    }
}
