package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
// + Application, ApplicationRepository, FRKKTaskService, коды статусов/нотификаций из вашего проекта

/**
 * "Создать задачу в ФРКК на обработку заявки" с реакцией на результат — одинаково для первичной проверки
 * (ApplicationSpmHandler) и уточнённой резолюции (ApplicationClarificationHandler):
 *  a. задача создана -> substatus UNPROCESSED_TASK_CREATED [+ update/activity EXECUTE];
 *  b. не создана -> DECLINED / DECLINED_TASK_ERROR / FRKK_TASK_ERROR, статус в client-cash [+ update/activity CANCEL].
 * Отличаются только тексты EXECUTE/CANCEL.
 *
 * Заменяет handleDocumentOnSuccess / handleDocumentOnError из BankCashCheckFraudService
 * и BankCashClarifiedResolutionService.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ApplicationFrkkTaskLauncher {

    private final FRKKTaskService frkkTaskService;
    private final ApplicationRepository applicationRepository;
    private final ApplicationStatusUpdater statusUpdater;
    private final SpmActivityNotifier activityNotifier;

    /**
     * @param executeOnCreated описание для EXECUTE при успешном создании задачи; null — не отправлять
     * @param cancelOnFailed   описание для CANCEL при ошибке создания задачи; null — не отправлять
     */
    public void launch(Application application, String executeOnCreated, String cancelOnFailed) {
        // колбэки перечитывают заявку из БД — сохраняем изменения заранее
        applicationRepository.saveAndFlush(application);
        frkkTaskService.sendApplicationProcessingTask(application,
                id -> onTaskCreated(id, executeOnCreated),
                id -> onTaskFailed(id, cancelOnFailed));
    }

    private void onTaskCreated(UUID id, String executeDescription) {
        applicationRepository.findById(id).ifPresentOrElse(application -> {
            application.setBankSubstatusCode(ApplicationBankSubstatusCode.UNPROCESSED_TASK_CREATED);
            applicationRepository.saveAndFlush(application);
            if (executeDescription != null) {
                activityNotifier.execute(application, executeDescription);
            }
        }, () -> log.warn("Задача ФРКК создана, но заявка {} не найдена", id));
    }

    private void onTaskFailed(UUID id, String cancelDescription) {
        applicationRepository.findById(id).ifPresentOrElse(application -> {
            application.setApplicationNotificationCode(ApplicationNotificationCode.FRKK_TASK_ERROR);
            statusUpdater.update(application, ApplicationBankStatusCode.DECLINED,
                    ApplicationBankSubstatusCode.DECLINED_TASK_ERROR, "");
            if (cancelDescription != null) {
                activityNotifier.cancel(application, cancelDescription);
            }
        }, () -> log.warn("Ошибка создания задачи ФРКК, заявка {} не найдена", id));
    }
}
