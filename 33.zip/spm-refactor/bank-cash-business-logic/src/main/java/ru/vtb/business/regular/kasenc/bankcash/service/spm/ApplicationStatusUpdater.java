package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
// + Application, ApplicationRepository, ClientCashExchangeService, коды статусов из вашего проекта

/**
 * Смена статуса заявки + отправка обновления в client-cash.
 * Нужен и заявке, и расходному документу (DENY по cashout обновляет связанную заявку).
 */
@Component
@RequiredArgsConstructor
public class ApplicationStatusUpdater {

    private final ApplicationRepository applicationRepository;
    private final ClientCashExchangeService clientCashExchangeService;

    public void update(Application application,
                       ApplicationBankStatusCode statusCode,
                       ApplicationBankSubstatusCode substatusCode,
                       String statusMessage) {
        application.setBankStatusCode(statusCode);
        application.setBankSubstatusCode(substatusCode);
        application.setStatusMessage(statusMessage);
        applicationRepository.saveAndFlush(application);
        clientCashExchangeService.sendApplicationStatusUpdate(
                application.getId(),
                statusCode != null ? statusCode.name() : null,
                substatusCode != null ? substatusCode.name() : null,
                statusMessage);
    }
}
