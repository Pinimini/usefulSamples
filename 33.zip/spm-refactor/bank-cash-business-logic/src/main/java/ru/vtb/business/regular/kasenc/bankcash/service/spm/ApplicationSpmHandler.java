package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
import ru.vtb.business.regular.kasenc.spm.SpmDocumentHandler;
import ru.vtb.business.regular.kasenc.spm.SpmOutcome;
import ru.vtb.business.regular.kasenc.spm.client.SpmAnalyzeRequest;
// + Application, SpmMapper, коды статусов/нотификаций из вашего проекта

/**
 * Реакции заявки на первичную резолюцию СПМ (страница "Интеграция client-cash с bank-cash").
 * Сценарий заявки после проверки ничего не делает, SpmOutcome здесь информативный.
 */
@Component
@RequiredArgsConstructor
public class ApplicationSpmHandler implements SpmDocumentHandler<Application> {

    private static final String ALLOW_CANCELLED = "Операция отменена";

    private final ApplicationFrkkTaskLauncher frkkTaskLauncher;
    private final ApplicationStatusUpdater statusUpdater;
    private final ApplicationSpmDeadlineCalculator deadlineCalculator;
    private final SpmMapper spmMapper;

    @Override
    public String documentType() {
        return "APPLICATION";
    }

    @Override
    public SpmAnalyzeRequest buildAnalyzeRequest(Application application) {
        return spmMapper.mapApplicationToSAVOBSKAnalyzeRequest(application);
    }

    @Override
    public SpmOutcome onAllow(Application application) {
        frkkTaskLauncher.launch(application, null, ALLOW_CANCELLED);
        return SpmOutcome.PROCEED;
    }

    @Override
    public SpmOutcome onDeny(Application application) {
        application.setApplicationNotificationCode(ApplicationNotificationCode.DENIED_SPM);
        statusUpdater.update(application, ApplicationBankStatusCode.DECLINED,
                ApplicationBankSubstatusCode.DENIED_SPM, "");
        return SpmOutcome.STOP;
    }

    @Override
    public SpmOutcome onReview(Application application) {
        deadlineCalculator.apply(application);
        statusUpdater.update(application, ApplicationBankStatusCode.CONTROL_SPM, null, "");
        return SpmOutcome.STOP;
    }

    @Override
    public SpmOutcome onUnexpected(Application application) {
        frkkTaskLauncher.launch(application,
                SpmActivityNotifier.UNEXPECTED_RESOLUTION,
                SpmActivityNotifier.UNEXPECTED_RESOLUTION_CANCELLED);
        return SpmOutcome.PROCEED;
    }

    @Override
    public SpmOutcome onTechChallenge(Application application) {
        frkkTaskLauncher.launch(application, null, null);
        return SpmOutcome.PROCEED;
    }
}
