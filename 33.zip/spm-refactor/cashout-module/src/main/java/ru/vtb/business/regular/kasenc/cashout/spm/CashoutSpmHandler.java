package ru.vtb.business.regular.kasenc.cashout.spm;

import java.time.Duration;
import java.time.OffsetDateTime;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
import ru.vtb.business.regular.kasenc.spm.SpmDocumentHandler;
import ru.vtb.business.regular.kasenc.spm.SpmOutcome;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;
import ru.vtb.business.regular.kasenc.spm.client.SpmAnalyzeRequest;
// + Cashout, CashoutRepository, CashoutStatusCode, CashoutNotificationCode, CashoutSpmMapper, Application

/**
 * Реакции расходного документа на первичную резолюцию (страница "POST api/v1/bank_cash/cashouts", п.16).
 * Связанная заявка берётся из связи Cashout.application (@OneToOne).
 *
 * ВАЖНО: процессоры работают вне транзакции. Если связь LAZY, загружайте cashout вместе с заявкой
 * (@EntityGraph(attributePaths = "application") / join fetch), иначе будет LazyInitializationException.
 */
@Component
@RequiredArgsConstructor
public class CashoutSpmHandler implements SpmDocumentHandler<Cashout> {

    private static final Duration TECH_ALLOW_WINDOW = Duration.ofHours(12);
    private static final String TECH_ALLOW_DESCRIPTION =
            "С момента проверки заявки на проведение операции прошло менее 12 часов (технический ALLOW)";

    private final CashoutRepository cashoutRepository;
    private final CashoutSpmActions actions;
    private final SpmActivityNotifier activityNotifier;
    private final CashoutSpmMapper cashoutSpmMapper;

    @Override
    public String documentType() {
        return "CASHOUT";
    }

    @Override
    public SpmAnalyzeRequest buildAnalyzeRequest(Cashout cashout) {
        return cashoutSpmMapper.toAnalyzeRequest(cashout);
    }

    @Override
    public SpmOutcome onAllow(Cashout cashout) {
        actions.createControllerTask(cashout);
        return SpmOutcome.PROCEED;
    }

    @Override
    public SpmOutcome onDeny(Cashout cashout) {
        actions.deny(cashout);
        return SpmOutcome.STOP;
    }

    @Override
    public SpmOutcome onReview(Cashout cashout) {
        if (isTechnicalAllow(cashout)) {
            cashout.setSpmActionCode(ActionCode.AUTO_ALLOW);
            cashout.setSpmActionTimestamp(OffsetDateTime.now());
            actions.createControllerTask(cashout);
            activityNotifier.execute(cashout, TECH_ALLOW_DESCRIPTION);
            return SpmOutcome.PROCEED;
        }

        cashout.setStatusCode(CashoutStatusCode.CONTROL_SPM);
        cashout.setSubstatusCode(null);
        cashout.setSpmDeadline(cashout.getSpmActionTimestamp().plusHours(2));
        actions.setNotification(cashout, CashoutNotificationCode.SPM_CHECK_2);
        cashoutRepository.saveAndFlush(cashout);
        return SpmOutcome.STOP;
    }

    @Override
    public SpmOutcome onUnexpected(Cashout cashout) {
        actions.createControllerTask(cashout);
        // для расходного документа EXECUTE отправляется сразу, не по результату создания задачи
        activityNotifier.execute(cashout, SpmActivityNotifier.UNEXPECTED_RESOLUTION);
        return SpmOutcome.PROCEED;
    }

    @Override
    public SpmOutcome onTechChallenge(Cashout cashout) {
        actions.createControllerTask(cashout);
        return SpmOutcome.PROCEED;
    }

    /**
     * (cashout.spm_action_timestamp - application.created_timestamp) < 12 ч
     * и application.spm_action_code = REVIEW_ALLOW.
     */
    private boolean isTechnicalAllow(Cashout cashout) {
        Application application = cashout.getApplication();
        Duration sinceApplication = Duration.between(
                application.getCreatedTimestamp().toInstant(),
                cashout.getSpmActionTimestamp().toInstant());
        return sinceApplication.compareTo(TECH_ALLOW_WINDOW) < 0
                && application.getSpmActionCode() == ActionCode.REVIEW_ALLOW;
    }
}
