package ru.vtb.business.regular.kasenc.cashout.spm;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
import ru.vtb.business.regular.kasenc.spm.clarification.SpmClarificationHandler;
import ru.vtb.business.regular.kasenc.spm.clarification.SpmExpiryPolicy;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;
// + Cashout, CashoutRepository, CashoutStatusCode, ProductTypeCode

/**
 * Уточнённая резолюция по РКО — п.4 "Обработка РКО" страницы
 * "Задания по расписанию для проверки уточнённой резолюции".
 */
@Order(2)
@Component
@RequiredArgsConstructor
public class CashoutClarificationHandler implements SpmClarificationHandler<Cashout> {

    private static final String EXPIRED_CANCEL = "Истекло время ожидания уточняющей резолюции (технический DENY)";

    private final CashoutRepository cashoutRepository;
    private final CashoutSpmActions actions;
    private final SpmActivityNotifier activityNotifier;

    @Value("${SPM_CASHWITHOUTCHECK_CHECKSFRAUD_ENABLED:false}")
    private boolean enabled;

    @Override
    public String documentType() {
        return "CASHOUT";
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * product_type_code = CASHWITHOUTCHECK и status_code = CONTROL_SPM.
     * В репозитории — с @EntityGraph(attributePaths = "application"): заявка нужна в deny().
     */
    @Override
    public List<Cashout> findAwaitingClarification() {
        return cashoutRepository.findAllWithApplicationByProductTypeCodeAndStatusCode(
                ProductTypeCode.CASHWITHOUTCHECK, CashoutStatusCode.CONTROL_SPM);
    }

    @Override
    public SpmExpiryPolicy expiryPolicy() {
        return SpmExpiryPolicy.AUTO_DENY;
    }

    /** ALLOW п.5–10. */
    @Override
    public void onAllow(Cashout cashout) {
        allowAfterReview(cashout);
    }

    /** DENY п.5–13. */
    @Override
    public void onDeny(Cashout cashout) {
        actions.deny(cashout);
        actions.createSpmCompletionTask(cashout, ActionCode.DENY);
    }

    /** Непредусмотренная резолюция — как ALLOW (операция продолжена). */
    @Override
    public void onUnexpected(Cashout cashout) {
        allowAfterReview(cashout);
    }

    /** Шаг iii, C–L: технический DENY. */
    @Override
    public void onDeadlineExpired(Cashout cashout) {
        actions.deny(cashout);
        actions.createSpmCompletionTask(cashout, ActionCode.DENY);
        activityNotifier.cancel(cashout, EXPIRED_CANCEL);
    }

    private void allowAfterReview(Cashout cashout) {
        actions.toControl(cashout);
        actions.createControllerTask(cashout);
        actions.createSpmCompletionTask(cashout, ActionCode.ALLOW);
    }
}
