package ru.vtb.business.regular.kasenc.cashout.spm;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.bankcash.service.spm.ApplicationStatusUpdater;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;
// + Cashout, CashoutRepository, CashoutStatusCode, CashoutSubstatusCode, CashoutNotificationCode,
//   CashoutNotificationRepository, CashoutFrkkTaskService, Application, коды статусов заявки

/**
 * Действия над расходным документом, общие для первичной проверки (CashoutSpmHandler)
 * и уточнённой резолюции (CashoutClarificationHandler).
 */
@Component
@RequiredArgsConstructor
public class CashoutSpmActions {

    private final CashoutRepository cashoutRepository;
    private final CashoutNotificationRepository cashoutNotificationRepository; // справочник cashout_notification
    private final CashoutFrkkTaskService cashoutFrkkTaskService;
    private final ApplicationStatusUpdater applicationStatusUpdater;

    /**
     * DENY: РКО -> DENIED / DENIED_SPM / DENIED_SPM + reason_description,
     * связанная заявка -> DECLINED / DENIED_SPM / DENIED_SPM, статус заявки в client-cash.
     * Совпадает в первичной таблице, в таблице уточнённой резолюции (DENY п.5–12) и при истечении дедлайна.
     */
    public void deny(Cashout cashout) {
        cashout.setStatusCode(CashoutStatusCode.DENIED);
        cashout.setSubstatusCode(CashoutSubstatusCode.DENIED_SPM);
        setNotification(cashout, CashoutNotificationCode.DENIED_SPM);
        cashoutRepository.saveAndFlush(cashout);

        Application application = cashout.getApplication();
        application.setApplicationNotificationCode(ApplicationNotificationCode.DENIED_SPM);
        // в таблице DENY уточнённой резолюции: bank_status_code = DECLINED, bank_substatus_code = DENIED_SPM
        // (в шаге iii и в первичной таблице написано "bank_substatus_code = 'DECLINED'" — считаем опечаткой)
        applicationStatusUpdater.update(application, ApplicationBankStatusCode.DECLINED,
                ApplicationBankSubstatusCode.DENIED_SPM, "");
    }

    /** ALLOW / непредусмотренная после REVIEW: status CONTROL, substatus, notification и reason — NULL. */
    public void toControl(Cashout cashout) {
        cashout.setStatusCode(CashoutStatusCode.CONTROL);
        cashout.setSubstatusCode(null);
        cashout.setNotificationCode(null);
        cashout.setReasonDescription(null);
        cashoutRepository.saveAndFlush(cashout);
    }

    public void setNotification(Cashout cashout, CashoutNotificationCode code) {
        cashout.setNotificationCode(code);
        cashout.setReasonDescription(cashoutNotificationRepository.getDescriptionByCode(code));
    }

    /** "Создать задачу в ФРКК на контролера по расходному документу" + запись в таблицу асинхронных взаимодействий. */
    public void createControllerTask(Cashout cashout) {
        cashoutRepository.saveAndFlush(cashout);
        cashoutFrkkTaskService.createControllerTask(cashout);
    }

    /**
     * "Завершение ожидания проверки СПМ по кассовому документу (для случая ALLOW / DENY)"
     * + запись в таблицу асинхронных взаимодействий.
     */
    public void createSpmCompletionTask(Cashout cashout, ActionCode result) {
        cashoutFrkkTaskService.createSpmCompletionTask(cashout, result);
    }
}
