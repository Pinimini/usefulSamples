package ru.vtb.business.regular.kasenc.cashin.spm;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
import ru.vtb.business.regular.kasenc.spm.clarification.SpmClarificationHandler;
import ru.vtb.business.regular.kasenc.spm.clarification.SpmExpiryPolicy;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;
// + Cashin, CashinRepository, CashinStatusCode, CashinProductTypeCode

/**
 * Уточнённая резолюция по ОВН — п.5 "Обработка ОВН" страницы
 * "Задания по расписанию для проверки уточнённой резолюции".
 */
@Order(3)
@Component
@RequiredArgsConstructor
public class CashinClarificationHandler implements SpmClarificationHandler<Cashin> {

    private static final String EXPIRED_CANCEL = "Истекло время ожидания уточняющей резолюции (технический DENY)";

    private final CashinRepository cashinRepository;
    private final CashinSpmActions actions;
    private final SpmActivityNotifier activityNotifier;

    @Value("${SPM_OVN_CHECKSFRAUD_ENABLED:false}")
    private boolean enabled;

    @Override
    public String documentType() {
        return "CASHIN";
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    /** product_type_code = OVN и status_code = CONTROL_SPM. */
    @Override
    public List<Cashin> findAwaitingClarification() {
        return cashinRepository.findAllByProductTypeCodeAndStatusCode(
                CashinProductTypeCode.OVN, CashinStatusCode.CONTROL_SPM);
    }

    @Override
    public SpmExpiryPolicy expiryPolicy() {
        return SpmExpiryPolicy.AUTO_DENY;
    }

    /** ALLOW п.5–10. */
    @Override
    public void onAllow(Cashin cashin) {
        allowAfterReview(cashin);
    }

    /** DENY: статус, субстатус, нотификация, reason + задача "Завершение ожидания (DENY)". */
    @Override
    public void onDeny(Cashin cashin) {
        actions.deny(cashin);
        actions.createSpmCompletionTask(cashin, ActionCode.DENY);
    }

    /** Непредусмотренная резолюция п.5–10 — как ALLOW (операция продолжена). */
    @Override
    public void onUnexpected(Cashin cashin) {
        allowAfterReview(cashin);
    }

    /** Шаг iii, C–I: технический DENY. */
    @Override
    public void onDeadlineExpired(Cashin cashin) {
        actions.deny(cashin);
        actions.createSpmCompletionTask(cashin, ActionCode.DENY);
        activityNotifier.cancel(cashin, EXPIRED_CANCEL);
    }

    private void allowAfterReview(Cashin cashin) {
        actions.toControl(cashin);
        actions.createControllerTask(cashin);
        actions.createSpmCompletionTask(cashin, ActionCode.ALLOW);
    }
}
