package ru.vtb.business.regular.kasenc.cashin.spm;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;
// + Cashin, CashinRepository, CashinStatusCode, CashinSubstatusCode, CashinNotificationCode,
//   CashinNotificationRepository, CashinFrkkTaskService

/**
 * Действия над приходным документом, общие для первичной проверки (CashinSpmHandler)
 * и уточнённой резолюции (CashinClarificationHandler).
 */
@Component
@RequiredArgsConstructor
public class CashinSpmActions {

    private final CashinRepository cashinRepository;
    private final CashinNotificationRepository cashinNotificationRepository; // справочник cashin_notification
    private final CashinFrkkTaskService cashinFrkkTaskService;

    /** DENY: DENIED / DENIED_SPM / DENIED_SPM + reason_description. */
    public void deny(Cashin cashin) {
        cashin.setStatusCode(CashinStatusCode.DENIED);
        cashin.setSubstatusCode(CashinSubstatusCode.DENIED_SPM);
        setNotification(cashin, CashinNotificationCode.DENIED_SPM);
        cashinRepository.save(cashin);
    }

    /** ALLOW / непредусмотренная после REVIEW: status CONTROL, substatus, notification и reason — NULL. */
    public void toControl(Cashin cashin) {
        cashin.setStatusCode(CashinStatusCode.CONTROL);
        cashin.setSubstatusCode(null);
        cashin.setNotificationCode(null);
        cashin.setReasonDescription(null);
        cashinRepository.save(cashin);
    }

    public void setNotification(Cashin cashin, CashinNotificationCode code) {
        cashin.setNotificationCode(code);
        cashin.setReasonDescription(cashinNotificationRepository.getDescriptionByCode(code));
    }

    /** "Создать задачу в ФРКК на контролера по приходному документу" + запись в таблицу асинхронных взаимодействий. */
    public void createControllerTask(Cashin cashin) {
        cashinFrkkTaskService.createControllerTask(cashin);
    }

    /**
     * "Завершение ожидания проверки СПМ по кассовому документу (для случая ALLOW / DENY)"
     * + запись в таблицу асинхронных взаимодействий по приходному документу.
     */
    public void createSpmCompletionTask(Cashin cashin, ActionCode result) {
        cashinFrkkTaskService.createSpmCompletionTask(cashin, result);
    }
}
