package ru.vtb.business.regular.kasenc.spm.clarification;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * Таблица "если http-код = 200" для уточнённой резолюции — одинакова для заявки, РКО и ОВН.
 * NO_ANSWER — резолюции нет, переходим к проверке spm_deadline.
 */
class SpmClarificationResolverTest {

    @ParameterizedTest(name = "actionCode={0} -> {1}")
    @CsvSource(nullValues = "NULL", value = {
            "ALLOW,     ALLOW",
            "DENY,      DENY",
            "REVIEW,    UNEXPECTED",   // по аналитике REVIEW вычеркнут из исключений — уточнить
            "CHALLENGE, UNEXPECTED",
            "OTHER,     UNEXPECTED",
            "NULL,      NO_ANSWER",
            "'',        NO_ANSWER",
    })
    void resolve(String actionCode, String expected) {
        Optional<SpmClarification> actual = SpmClarificationResolver.resolve(actionCode);
        assertEquals(expected, actual.map(Enum::name).orElse("NO_ANSWER"));
    }
}
