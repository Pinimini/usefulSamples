package ru.vtb.business.regular.kasenc.spm;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;

/**
 * Таблица "если http-код = 200" — одинакова для заявки, расходного и приходного документов.
 */
class SpmResolutionResolverTest {

    @ParameterizedTest(name = "actionCode={0}, actionSubCode={1} -> {2}")
    @CsvSource(nullValues = "NULL", value = {
            // 'ALLOW' при любом подкоде или без него
            "ALLOW,      NULL,  ALLOW",
            "ALLOW,      AML,   ALLOW",
            "ALLOW,      OTHER, ALLOW",
            // 'AML' + 'DENY' / 'REVIEW'
            "DENY,       AML,   DENY",
            "REVIEW,     AML,   REVIEW",
            // 'AML' + <> (ALLOW, DENY, REVIEW) или отсутствует
            "CHALLENGE,  AML,   UNEXPECTED",
            "AUTO_ALLOW, AML,   UNEXPECTED",
            "NULL,       AML,   UNEXPECTED",
            // <> 'AML' + <> 'ALLOW' или отсутствует
            "DENY,       NULL,  UNEXPECTED",
            "DENY,       OTHER, UNEXPECTED",
            "REVIEW,     NULL,  UNEXPECTED",
            "REVIEW,     OTHER, UNEXPECTED",
            "CHALLENGE,  OTHER, UNEXPECTED",
            "NULL,       NULL,  UNEXPECTED",
            // подкод отсутствует + 'CHALLENGE' -> недоступность СПМ
            "CHALLENGE,  NULL,  TECH_CHALLENGE",
            "CHALLENGE,  '',    TECH_CHALLENGE",
    })
    void resolve(ActionCode actionCode, String actionSubCode, SpmResolution expected) {
        assertEquals(expected, SpmResolutionResolver.resolve(actionCode, actionSubCode));
    }
}
