package ru.vtb.business.regular.kasenc.spm.clarification;

import java.time.OffsetDateTime;
import ru.vtb.business.regular.kasenc.spm.SpmDocument;

/**
 * Документ, по которому СПМ может прислать уточнённую резолюцию после REVIEW.
 * spm_deadline уже есть у Application, Cashout и Cashin — достаточно поменять
 * "implements SpmDocument" на "implements SpmClarifiableDocument".
 */
public interface SpmClarifiableDocument extends SpmDocument {

    OffsetDateTime getSpmDeadline();
}
