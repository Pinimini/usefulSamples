package ru.vtb.business.regular.kasenc.spm;

/**
 * Порт метрик. Ядро не знает про BankCashMonitoring (он в модуле bank-cash).
 * В приложении должна быть ровно одна реализация — сейчас это BankCashSpmMetrics.
 */
public interface SpmMetrics {

    void increment(SpmResolution resolution, String documentType);
}
