package ru.vtb.business.regular.kasenc.spm;

public record SpmCheckResult(SpmResolution resolution, SpmOutcome outcome) {

    public boolean proceed() {
        return outcome == SpmOutcome.PROCEED;
    }
}
