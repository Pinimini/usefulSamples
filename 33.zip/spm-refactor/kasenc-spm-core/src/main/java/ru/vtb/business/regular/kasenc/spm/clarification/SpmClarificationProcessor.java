package ru.vtb.business.regular.kasenc.spm.clarification;

import feign.FeignException;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmMetrics;
import ru.vtb.business.regular.kasenc.spm.client.CheckFraudLegalClient;
import ru.vtb.business.regular.kasenc.spm.client.GetObjectStatusDto;
import ru.vtb.business.regular.kasenc.spm.client.SpmSendResultActionCode;
import ru.vtb.business.regular.kasenc.spm.client.SpmSendResultErrorCode;
import ru.vtb.business.regular.kasenc.spm.client.SpmSendResultRequest;

/**
 * Задание по расписанию "проверка уточнённой резолюции" (команда планировщика SPMResolutions):
 * для каждого типа документа в CONTROL_SPM -> object_status -> send_result_response -> реакция документа,
 * а без резолюции — решение по умолчанию после spm_deadline.
 *
 * Не помечать @Transactional: HTTP-вызовы на каждый документ.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SpmClarificationProcessor {

    static final String UNEXPECTED_DESCRIPTION = "Непредусмотренная резолюция. Операция продолжена";

    private final CheckFraudLegalClient checkFraudClient;
    private final SpmMetrics spmMetrics;
    /** Все обработчики из всех модулей; порядок — @Order (заявки, РКО, ОВН). */
    private final List<SpmClarificationHandler<?>> handlers;

    public void run(OffsetDateTime nowUtc) {
        for (SpmClarificationHandler<?> handler : handlers) {
            if (!handler.isEnabled()) {
                log.info("Уточнённые резолюции {}: рубильник выключен", handler.documentType());
                continue;
            }
            clarifyAll(handler, nowUtc);
        }
    }

    public <D extends SpmClarifiableDocument> void clarifyAll(SpmClarificationHandler<D> handler, OffsetDateTime nowUtc) {
        List<D> documents = handler.findAwaitingClarification();
        log.info("Уточнённые резолюции {}: документов в CONTROL_SPM {}", handler.documentType(), documents.size());
        for (D document : documents) {
            try {
                clarify(document, handler, nowUtc);
            } catch (RuntimeException e) {
                // ошибка по одному документу не останавливает цикл; документ остаётся в CONTROL_SPM
                // и будет обработан при следующем запуске
                log.error("Ошибка обработки уточнённой резолюции {} {}", handler.documentType(), document.getId(), e);
            }
        }
    }

    public <D extends SpmClarifiableDocument> void clarify(D document, SpmClarificationHandler<D> handler,
                                                          OffsetDateTime nowUtc) {
        Optional<SpmClarification> clarification = requestClarification(document, handler);
        if (clarification.isPresent()) {
            apply(document, handler, clarification.get());
        } else if (isDeadlineExpired(document, handler, nowUtc)) {
            expire(document, handler);
        } else {
            log.info("{} {}: уточнённой резолюции нет, ждём до {}",
                    handler.documentType(), document.getId(), document.getSpmDeadline());
        }
    }

    private <D extends SpmClarifiableDocument> Optional<SpmClarification> requestClarification(
            D document, SpmClarificationHandler<D> handler) {
        try {
            GetObjectStatusDto response = checkFraudClient.getObjectStatusDto(
                    document.getProductTypeCode().name(), document.getId(), null);
            log.info("Ответ check-fraud object_status для {} {}: {}", handler.documentType(), document.getId(), response);
            return SpmClarificationResolver.resolve(response);
        } catch (FeignException e) {
            // "ИНАЧЕ или если http-код <> 200 — перейти к следующему шагу" (проверка дедлайна)
            log.warn("object_status для {} {} вернул {}, переходим к проверке дедлайна",
                    handler.documentType(), document.getId(), e.status());
            return Optional.empty();
        }
    }

    private <D extends SpmClarifiableDocument> void apply(D document, SpmClarificationHandler<D> handler,
                                                         SpmClarification clarification) {
        log.info("{} {}: уточнённая резолюция {}", handler.documentType(), document.getId(), clarification);
        // сначала send_result_response: если он упадёт, документ не изменится и повторится при следующем запуске
        sendResult(document, toSendResultRequest(clarification));
        spmMetrics.increment(clarification.getMetric(), handler.documentType());
        document.setSpmActionCode(clarification.getSpmActionCode());
        document.setSpmActionTimestamp(OffsetDateTime.now());

        switch (clarification) {
            case ALLOW -> handler.onAllow(document);
            case DENY -> handler.onDeny(document);
            case UNEXPECTED -> handler.onUnexpected(document);
        }
    }

    private <D extends SpmClarifiableDocument> void expire(D document, SpmClarificationHandler<D> handler) {
        SpmExpiryPolicy policy = handler.expiryPolicy();
        log.info("{} {}: spm_deadline {} истёк, решение по умолчанию {}",
                handler.documentType(), document.getId(), document.getSpmDeadline(), policy);
        sendResult(document, fail(policy.getSendResultDescription()));
        document.setSpmActionCode(policy.getSpmActionCode());
        document.setSpmActionTimestamp(OffsetDateTime.now());
        handler.onDeadlineExpired(document);
    }

    private <D extends SpmClarifiableDocument> boolean isDeadlineExpired(D document, SpmClarificationHandler<D> handler,
                                                                        OffsetDateTime nowUtc) {
        OffsetDateTime deadline = document.getSpmDeadline();
        if (deadline == null) {
            log.warn("{} {} в CONTROL_SPM без spm_deadline — решение по умолчанию не применяется",
                    handler.documentType(), document.getId());
            return false;
        }
        return deadline.isBefore(nowUtc);
    }

    private void sendResult(SpmClarifiableDocument document, SpmSendResultRequest request) {
        checkFraudClient.sendResultResponse(request, document.getProductTypeCode().name(), document.getId(), null);
    }

    private static SpmSendResultRequest toSendResultRequest(SpmClarification clarification) {
        return switch (clarification) {
            case ALLOW -> success(SpmSendResultActionCode.ALLOW);
            case DENY -> success(SpmSendResultActionCode.DENY);
            case UNEXPECTED -> fail(UNEXPECTED_DESCRIPTION);
        };
    }

    private static SpmSendResultRequest success(SpmSendResultActionCode actionCode) {
        return SpmSendResultRequest.builder()
                .actionCode(actionCode)
                .errorCode(SpmSendResultErrorCode.SUCCESS)
                .build();
    }

    private static SpmSendResultRequest fail(String description) {
        return SpmSendResultRequest.builder()
                .errorDescription(description)
                .errorCode(SpmSendResultErrorCode.FAIL)
                .build();
    }
}
