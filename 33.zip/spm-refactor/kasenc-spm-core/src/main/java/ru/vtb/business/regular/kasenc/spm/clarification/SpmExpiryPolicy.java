package ru.vtb.business.regular.kasenc.spm.clarification;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;

/**
 * Решение по умолчанию, когда spm_deadline истёк, а уточнённой резолюции нет (шаг iii аналитики).
 * Единственное место, где документы расходятся по коду и тексту send_result_response.
 */
@Getter
@RequiredArgsConstructor
public enum SpmExpiryPolicy {

    /** Заявка: технический ALLOW. */
    AUTO_ALLOW(ActionCode.REVIEW_AUTO_ALLOW, "Время ожидания REVIEW истекло. Операция продолжена"),

    /** РКО и ОВН: технический DENY. */
    AUTO_DENY(ActionCode.REVIEW_AUTO_DENY, "Время ожидания REVIEW истекло. Операция отменена");

    private final ActionCode spmActionCode;
    private final String sendResultDescription;
}
