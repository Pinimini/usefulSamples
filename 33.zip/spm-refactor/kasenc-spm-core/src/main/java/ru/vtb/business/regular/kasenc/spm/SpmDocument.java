package ru.vtb.business.regular.kasenc.spm;

import java.time.OffsetDateTime;
import java.util.UUID;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;

/**
 * Документ, который можно отправить на проверку в СПМ.
 * Геттеры/сеттеры у сущностей уже есть (Lombok): достаточно дописать "implements SpmDocument"
 * в Application, Cashout, Cashin. Enum<?> — чтобы ядро не зависело от enum'ов типа продукта модулей
 * (ковариантный возврат ProductTypeCode / CashinProductTypeCode подходит).
 */
public interface SpmDocument {

    UUID getId();

    Enum<?> getProductTypeCode();

    void setSpmActionCode(ActionCode spmActionCode);

    void setSpmActionTimestamp(OffsetDateTime spmActionTimestamp);
}
