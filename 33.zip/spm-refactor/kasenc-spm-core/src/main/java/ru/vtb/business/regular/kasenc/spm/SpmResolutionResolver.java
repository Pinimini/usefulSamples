package ru.vtb.business.regular.kasenc.spm;

import java.util.Optional;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;
import ru.vtb.business.regular.kasenc.spm.client.SpmAnalyzeResponse;

/**
 * Первые две колонки таблицы "если http-код = 200": (actionSubCode, actionCode) -> резолюция.
 * Чистая функция без Spring и БД, покрыта SpmResolutionResolverTest строка-в-строку по аналитике.
 */
public final class SpmResolutionResolver {

    private static final String AML = "AML";

    private SpmResolutionResolver() {
    }

    public static SpmResolution resolve(SpmAnalyzeResponse response) {
        var rule = Optional.ofNullable(response)
                .map(r -> r.getRiskResult())
                .map(r -> r.getTriggeredRule())
                .orElse(null);
        return rule == null
                ? SpmResolution.UNEXPECTED
                : resolve(rule.getActionCode(), rule.getActionSubCode());
    }

    public static SpmResolution resolve(ActionCode actionCode, String actionSubCode) {
        // actionCode отсутствует -> непредусмотренная резолюция
        if (actionCode == null) {
            return SpmResolution.UNEXPECTED;
        }
        boolean aml = AML.equals(actionSubCode);
        boolean noSubCode = actionSubCode == null || actionSubCode.isBlank();

        return switch (actionCode) {
            case ALLOW -> SpmResolution.ALLOW;                                    // подкод любой или отсутствует
            case DENY -> aml ? SpmResolution.DENY : SpmResolution.UNEXPECTED;
            case REVIEW -> aml ? SpmResolution.REVIEW : SpmResolution.UNEXPECTED;
            case CHALLENGE -> noSubCode ? SpmResolution.TECH_CHALLENGE : SpmResolution.UNEXPECTED;
            default -> SpmResolution.UNEXPECTED;
        };
    }
}
