package ru.vtb.business.regular.kasenc.spm;

import ru.vtb.business.regular.kasenc.spm.client.SpmAnalyzeRequest;

/**
 * Стратегия: реакция конкретного типа документа на каждую резолюцию СПМ
 * (правая колонка таблицы "Реакция в СУБО"). Реализуется в модуле документа.
 *
 * К моменту вызова onXxx процессор уже:
 *  - инкрементировал метрику,
 *  - проставил spm_action_code и spm_action_timestamp (не сохранил — сохраняет обработчик).
 * Обработчик может их переопределить (например, технический ALLOW в REVIEW для расходного документа).
 */
public interface SpmDocumentHandler<D extends SpmDocument> {

    /** Тип документа для логов и тега метрики: APPLICATION, CASHOUT, CASHIN. */
    String documentType();

    SpmAnalyzeRequest buildAnalyzeRequest(D document);

    SpmOutcome onAllow(D document);

    SpmOutcome onDeny(D document);

    SpmOutcome onReview(D document);

    SpmOutcome onUnexpected(D document);

    /** CHALLENGE без подкода, а также тех. ошибки вызова checks-fraud (5xx, 4xx кроме 400/404). */
    SpmOutcome onTechChallenge(D document);
}
