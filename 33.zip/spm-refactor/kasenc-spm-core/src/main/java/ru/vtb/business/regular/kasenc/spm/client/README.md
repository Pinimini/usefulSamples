# Клиент checks-fraud — ваш, ядро его не регистрирует

Ядро только внедряет готовые бины, зарегистрированные вашим приложением:

- `CheckFraudLegalClient` — ваш Feign-клиент (`@EnableFeignClients` остаётся в приложении);
- `SpmActivityMapper` — маппер для update/activity, `mapToUpdateActivity(UpdateType, String description, String actionSubCode)`.
  Сейчас этот метод в `SpmMapper` модуля заявок. Его нужно вынести туда же, где лежит клиент,
  или оставить в `SpmMapper`, если тот переедет вместе с клиентом.

Типы из клиента, которые использует ядро: `CheckFraudLegalClient`, `SpmAnalyzeRequest`, `SpmAnalyzeResponse`,
`ActionCode`, `UpdateType`, `SpmActivityMapper`. В импортах ядра они указаны из пакета
`ru.vtb.business.regular.kasenc.spm.client` — замените его на пакет вашего клиента.

Важно: ядро компилируется против этих классов, поэтому клиент с DTO должен лежать в модуле,
от которого ядро может зависеть (отдельный модуль клиента), а не в bank-cash-business-logic —
иначе получится цикл bank-cash -> core -> bank-cash.
