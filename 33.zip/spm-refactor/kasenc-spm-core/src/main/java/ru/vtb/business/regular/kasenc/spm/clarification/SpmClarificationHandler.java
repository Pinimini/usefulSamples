package ru.vtb.business.regular.kasenc.spm.clarification;

import java.util.List;

/**
 * Стратегия документа на этапе уточнённой резолюции (правая колонка "Реакция в СУБО").
 * Реализуется в модуле документа; процессор находит все реализации сам,
 * поэтому шедулер не зависит от модулей РКО и ОВН. Порядок обработки — @Order на реализации.
 *
 * К моменту вызова onXxx процессор уже:
 *  - отправил POST send_result_response,
 *  - инкрементировал метрику (кроме истечения дедлайна — в аналитике её нет),
 *  - проставил spm_action_code и spm_action_timestamp (не сохранил — сохраняет обработчик).
 */
public interface SpmClarificationHandler<D extends SpmClarifiableDocument> {

    /** Тип документа для логов и тега метрики: APPLICATION, CASHOUT, CASHIN. */
    String documentType();

    /** Рубильник: SPM_APPLICATION_CHECKSFRAUD_ENABLED / SPM_CASHWITHOUTCHECK_CHECKSFRAUD_ENABLED / SPM_OVN_CHECKSFRAUD_ENABLED. */
    boolean isEnabled();

    /** Документы, ожидающие уточнённой резолюции (статус CONTROL_SPM). */
    List<D> findAwaitingClarification();

    SpmExpiryPolicy expiryPolicy();

    void onAllow(D document);

    void onDeny(D document);

    void onUnexpected(D document);

    void onDeadlineExpired(D document);
}
