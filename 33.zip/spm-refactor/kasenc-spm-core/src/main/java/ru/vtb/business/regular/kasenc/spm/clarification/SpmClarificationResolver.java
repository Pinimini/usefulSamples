package ru.vtb.business.regular.kasenc.spm.clarification;

import java.util.Optional;
import ru.vtb.business.regular.kasenc.spm.client.GetObjectStatusDto;

/**
 * Таблица "если http-код = 200" страницы "Задания по расписанию для проверки уточнённой резолюции".
 * Смотрим только sendResultRequest.actionCode (колонка actionSubCode в аналитике вычеркнута).
 */
public final class SpmClarificationResolver {

    private SpmClarificationResolver() {
    }

    public static Optional<SpmClarification> resolve(GetObjectStatusDto response) {
        String actionCode = Optional.ofNullable(response)
                .map(r -> r.getSendResultRequest())
                .map(r -> r.getActionCode())
                .orElse(null);
        return resolve(actionCode);
    }

    /**
     * @return пусто — резолюции ещё нет ("ИНАЧЕ"): перейти к проверке spm_deadline
     */
    public static Optional<SpmClarification> resolve(String actionCode) {
        if (actionCode == null || actionCode.isBlank()) {
            return Optional.empty();
        }
        return Optional.of(switch (actionCode) {
            case "ALLOW" -> SpmClarification.ALLOW;
            case "DENY" -> SpmClarification.DENY;
            // "<> ('ALLOW' или 'DENY')": 'REVIEW' в аналитике вычеркнут из исключений, значит REVIEW тоже
            // непредусмотренная. TODO уточнить: если REVIEW = "СПМ ещё думает", его нужно вернуть в Optional.empty()
            default -> SpmClarification.UNEXPECTED;
        });
    }
}
