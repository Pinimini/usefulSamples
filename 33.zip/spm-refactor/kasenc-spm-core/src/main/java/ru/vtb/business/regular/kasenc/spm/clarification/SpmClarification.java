package ru.vtb.business.regular.kasenc.spm.clarification;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import ru.vtb.business.regular.kasenc.spm.SpmResolution;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;

/**
 * Уточнённая резолюция из GET /checks_fraud/object_status (sendResultRequest.actionCode).
 * spm_action_code и метрика одинаковы для заявки, РКО и ОВН.
 */
@Getter
@RequiredArgsConstructor
public enum SpmClarification {

    ALLOW(ActionCode.REVIEW_ALLOW, SpmResolution.ALLOW),
    DENY(ActionCode.REVIEW_DENY, SpmResolution.DENY),
    UNEXPECTED(ActionCode.REVIEW_AUTO_ALLOW, SpmResolution.UNEXPECTED);

    private final ActionCode spmActionCode;

    /** Метрики те же, что при первичной проверке: cash_bank_cash_analyze_success_allow / _deny / _fail_unexpected. */
    private final SpmResolution metric;
}
