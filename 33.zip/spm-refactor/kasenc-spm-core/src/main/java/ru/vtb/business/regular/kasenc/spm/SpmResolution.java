package ru.vtb.business.regular.kasenc.spm;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;

/**
 * Итоговая резолюция СПМ после разбора ответа checks-fraud.
 * Одинакова для заявки, расходного и приходного документов:
 * метрика и spm_action_code во всех трёх таблицах совпадают, различается только реакция.
 */
@Getter
@RequiredArgsConstructor
public enum SpmResolution {

    ALLOW("cash_bank_cash_analyze_success_allow", ActionCode.ALLOW),
    DENY("cash_bank_cash_analyze_success_deny", ActionCode.DENY),
    REVIEW("cash_bank_cash_analyze_success_review", ActionCode.REVIEW),
    UNEXPECTED("cash_bank_cash_analyze_fail_unexpected", ActionCode.AUTO_ALLOW),
    TECH_CHALLENGE("cash_bank_cash_analyze_fail_tech_challenge", ActionCode.AUTO_ALLOW);

    private final String metricName;
    private final ActionCode spmActionCode;
}
