package ru.vtb.business.regular.kasenc.cashin.spm;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
import ru.vtb.business.regular.kasenc.spm.SpmDocumentHandler;
import ru.vtb.business.regular.kasenc.spm.SpmOutcome;
import ru.vtb.business.regular.kasenc.spm.client.SpmAnalyzeRequest;
// + Cashin, CashinRepository, CashinStatusCode, CashinSubstatusCode, CashinNotificationCode,
//   CashinNotificationRepository, CashinSpmMapper из модуля приходных документов

/**
 * Реакции приходного документа (страница "POST api/v1/bank_cash/cashins", таблица "если http-код = 200").
 *
 * В отличие от заявки и расходного документа, задачу в ФРКК здесь не создаём:
 * при PROCEED вызывающий сценарий идёт дальше, к шагу 7 (контроль и задача в ФРКК).
 *
 * Имена Cashin*, репозиториев и маппера — предположения, подставьте свои.
 */
@Component
@RequiredArgsConstructor
public class CashinSpmHandler implements SpmDocumentHandler<Cashin> {

    private final CashinRepository cashinRepository;
    private final CashinNotificationRepository cashinNotificationRepository; // справочник cashin_notification
    private final SpmActivityNotifier activityNotifier;
    private final CashinSpmMapper cashinSpmMapper;

    @Override
    public String documentType() {
        return "CASHIN";
    }

    @Override
    public SpmAnalyzeRequest buildAnalyzeRequest(Cashin cashin) {
        // "Отправка запроса ANALYZE на проверку ОВН или ПКО по нотариусам в СПМ" — свой маппинг
        return cashinSpmMapper.toAnalyzeRequest(cashin);
    }

    /** п.4 "продолжить обработку далее". */
    @Override
    public SpmOutcome onAllow(Cashin cashin) {
        cashinRepository.save(cashin);
        return SpmOutcome.PROCEED;
    }

    /** п.4–7, п.8 "конец сценария". */
    @Override
    public SpmOutcome onDeny(Cashin cashin) {
        cashin.setStatusCode(CashinStatusCode.DENIED);
        cashin.setSubstatusCode(CashinSubstatusCode.DENIED_SPM);
        setNotification(cashin, CashinNotificationCode.DENIED_SPM);
        cashinRepository.save(cashin);
        return SpmOutcome.STOP;
    }

    /** п.4–8. Операция приостановлена до финальной резолюции СПМ. */
    @Override
    public SpmOutcome onReview(Cashin cashin) {
        cashin.setStatusCode(CashinStatusCode.CONTROL_SPM);
        cashin.setSubstatusCode(null);
        // в аналитике "cashout.spm_action_timestamp + 2 часа" — считаем опечаткой, берём cashin
        cashin.setSpmDeadline(cashin.getSpmActionTimestamp().plusHours(2));
        setNotification(cashin, CashinNotificationCode.SPM_CHECK_2);
        cashinRepository.save(cashin);
        return SpmOutcome.STOP;
    }

    /** п.4 POST update/activity EXECUTE. Дальше AUTO_ALLOW — продолжаем (уточнить у аналитика). */
    @Override
    public SpmOutcome onUnexpected(Cashin cashin) {
        cashinRepository.save(cashin);
        activityNotifier.execute(cashin, SpmActivityNotifier.UNEXPECTED_RESOLUTION);
        return SpmOutcome.PROCEED;
    }

    /** п.4 "продолжить обработку далее". */
    @Override
    public SpmOutcome onTechChallenge(Cashin cashin) {
        cashinRepository.save(cashin);
        return SpmOutcome.PROCEED;
    }

    private void setNotification(Cashin cashin, CashinNotificationCode code) {
        cashin.setNotificationCode(code);
        cashin.setReasonDescription(cashinNotificationRepository.getDescriptionByCode(code));
    }
}
