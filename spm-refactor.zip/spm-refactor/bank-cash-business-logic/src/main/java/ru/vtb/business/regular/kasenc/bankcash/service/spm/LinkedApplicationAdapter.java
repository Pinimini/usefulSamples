package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.cashout.spm.LinkedApplicationPort;
// + Application, ApplicationRepository, коды статусов/нотификаций из вашего проекта

/**
 * Реализация порта расходного документа на стороне заявок.
 * Здесь модуль заявок зависит от cashout-модуля (ради интерфейса порта). Если нужна обратная
 * зависимость или модули не должны знать друг о друге, положите адаптер в сборочный boot-модуль.
 */
@Component
@RequiredArgsConstructor
public class LinkedApplicationAdapter implements LinkedApplicationPort {

    private final ApplicationRepository applicationRepository;
    private final ApplicationStatusUpdater statusUpdater;

    @Override
    public Optional<LinkedApplication> find(UUID applicationId) {
        return applicationRepository.findById(applicationId)
                .map(application -> new LinkedApplication(
                        application.getId(),
                        application.getCreatedTimestamp().toInstant(),
                        application.getSpmActionCode()));
    }

    @Override
    public void denyBySpm(UUID applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new IllegalStateException("Не найдена заявка " + applicationId));
        application.setApplicationNotificationCode(ApplicationNotificationCode.DENIED_SPM);
        // TODO уточнить у аналитика: в таблице cashout п.8 "application.bank_substatus_code = 'DECLINED'",
        //  но DECLINED — это статус, а не субстатус. Здесь сделано как в DENY для заявки.
        statusUpdater.update(application, ApplicationBankStatusCode.DECLINED,
                ApplicationBankSubstatusCode.DENIED_SPM, "");
    }
}
