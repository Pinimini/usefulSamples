package ru.vtb.business.regular.kasenc.bankcash.service.spm;

import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
import ru.vtb.business.regular.kasenc.spm.SpmDocumentHandler;
import ru.vtb.business.regular.kasenc.spm.SpmOutcome;
import ru.vtb.business.regular.kasenc.spm.client.SpmAnalyzeRequest;
// + Application, ApplicationRepository, FRKKTaskService, SpmMapper, коды статусов/нотификаций из вашего проекта

/**
 * Реакции заявки на получение наличных (страница "Интеграция client-cash с bank-cash").
 * Сценарий заявки после проверки ничего не делает, SpmOutcome здесь информативный.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ApplicationSpmHandler implements SpmDocumentHandler<Application> {

    private static final String ALLOW_CANCELLED = "Операция отменена";

    private final FRKKTaskService frkkTaskService;
    private final ApplicationRepository applicationRepository;
    private final ApplicationStatusUpdater statusUpdater;
    private final ApplicationSpmDeadlineCalculator deadlineCalculator;
    private final SpmActivityNotifier activityNotifier;
    private final SpmMapper spmMapper;

    @Override
    public String documentType() {
        return "APPLICATION";
    }

    @Override
    public SpmAnalyzeRequest buildAnalyzeRequest(Application application) {
        return spmMapper.mapApplicationToSAVOBSKAnalyzeRequest(application);
    }

    @Override
    public SpmOutcome onAllow(Application application) {
        createFrkkTask(application, null, ALLOW_CANCELLED);
        return SpmOutcome.PROCEED;
    }

    @Override
    public SpmOutcome onDeny(Application application) {
        application.setApplicationNotificationCode(ApplicationNotificationCode.DENIED_SPM);
        statusUpdater.update(application, ApplicationBankStatusCode.DECLINED,
                ApplicationBankSubstatusCode.DENIED_SPM, "");
        return SpmOutcome.STOP;
    }

    @Override
    public SpmOutcome onReview(Application application) {
        deadlineCalculator.apply(application);
        statusUpdater.update(application, ApplicationBankStatusCode.CONTROL_SPM, null, "");
        return SpmOutcome.STOP;
    }

    @Override
    public SpmOutcome onUnexpected(Application application) {
        createFrkkTask(application,
                SpmActivityNotifier.UNEXPECTED_RESOLUTION,
                SpmActivityNotifier.UNEXPECTED_RESOLUTION_CANCELLED);
        return SpmOutcome.PROCEED;
    }

    @Override
    public SpmOutcome onTechChallenge(Application application) {
        createFrkkTask(application, null, null);
        return SpmOutcome.PROCEED;
    }

    /**
     * @param executeOnCreated описание для EXECUTE при успешном создании задачи; null — не отправлять
     * @param cancelOnFailed   описание для CANCEL при ошибке создания задачи; null — не отправлять
     */
    private void createFrkkTask(Application application, String executeOnCreated, String cancelOnFailed) {
        // колбэки перечитывают заявку из БД — сохраняем spm_action_code/timestamp заранее
        applicationRepository.saveAndFlush(application);
        frkkTaskService.sendApplicationProcessingTask(application,
                id -> onTaskCreated(id, executeOnCreated),
                id -> onTaskFailed(id, cancelOnFailed));
    }

    private void onTaskCreated(UUID id, String executeDescription) {
        applicationRepository.findById(id).ifPresentOrElse(application -> {
            application.setBankSubstatusCode(ApplicationBankSubstatusCode.UNPROCESSED_TASK_CREATED);
            applicationRepository.saveAndFlush(application);
            if (executeDescription != null) {
                activityNotifier.execute(application, executeDescription);
            }
        }, () -> log.warn("Задача ФРКК создана, но заявка {} не найдена", id));
    }

    private void onTaskFailed(UUID id, String cancelDescription) {
        applicationRepository.findById(id).ifPresentOrElse(application -> {
            application.setApplicationNotificationCode(ApplicationNotificationCode.FRKK_TASK_ERROR);
            statusUpdater.update(application, ApplicationBankStatusCode.DECLINED,
                    ApplicationBankSubstatusCode.DECLINED_TASK_ERROR, "");
            if (cancelDescription != null) {
                activityNotifier.cancel(application, cancelDescription);
            }
        }, () -> log.warn("Ошибка создания задачи ФРКК, заявка {} не найдена", id));
    }
}
