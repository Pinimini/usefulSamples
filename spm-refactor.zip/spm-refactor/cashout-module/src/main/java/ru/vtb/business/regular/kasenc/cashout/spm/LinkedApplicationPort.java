package ru.vtb.business.regular.kasenc.cashout.spm;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;

/**
 * Что расходному документу нужно от связанной заявки на получение наличных.
 * Порт позволяет модулю расходных документов не зависеть от модуля заявок.
 * Реализация — LinkedApplicationAdapter в модуле, где живёт Application.
 *
 * Если cashout-модуль и так зависит от модуля заявок, порт не нужен:
 * используйте ApplicationRepository и ApplicationStatusUpdater напрямую.
 */
public interface LinkedApplicationPort {

    Optional<LinkedApplication> find(UUID applicationId);

    /**
     * DENY по расходному документу: заявка отклоняется с нотификацией DENIED_SPM,
     * статус отправляется в client-cash.
     */
    void denyBySpm(UUID applicationId);

    record LinkedApplication(UUID id, Instant createdTimestamp, ActionCode spmActionCode) {
    }
}
