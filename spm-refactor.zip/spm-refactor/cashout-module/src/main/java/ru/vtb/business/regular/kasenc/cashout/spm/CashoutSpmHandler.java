package ru.vtb.business.regular.kasenc.cashout.spm;

import java.time.Duration;
import java.time.OffsetDateTime;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.vtb.business.regular.kasenc.cashout.spm.LinkedApplicationPort.LinkedApplication;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
import ru.vtb.business.regular.kasenc.spm.SpmDocumentHandler;
import ru.vtb.business.regular.kasenc.spm.SpmOutcome;
import ru.vtb.business.regular.kasenc.spm.client.ActionCode;
import ru.vtb.business.regular.kasenc.spm.client.SpmAnalyzeRequest;
// + Cashout, CashoutRepository, CashoutStatusCode, CashoutSubstatusCode, CashoutNotificationCode,
//   CashoutNotificationRepository, CashoutFrkkTaskService, CashoutSpmMapper из модуля расходных документов

/**
 * Реакции расходного документа (страница "POST api/v1/bank_cash/cashouts", п.16).
 * Имена Cashout*, репозиториев, маппера и сервиса задач ФРКК — предположения, подставьте свои.
 */
@Component
@RequiredArgsConstructor
public class CashoutSpmHandler implements SpmDocumentHandler<Cashout> {

    private static final Duration TECH_ALLOW_WINDOW = Duration.ofHours(12);
    private static final String TECH_ALLOW_DESCRIPTION =
            "С момента проверки заявки на проведение операции прошло менее 12 часов (технический ALLOW)";

    private final CashoutRepository cashoutRepository;
    private final CashoutNotificationRepository cashoutNotificationRepository; // справочник cashout_notification
    private final CashoutFrkkTaskService cashoutFrkkTaskService;               // задача на контролера + таблица асинхронных взаимодействий
    private final LinkedApplicationPort linkedApplicationPort;
    private final SpmActivityNotifier activityNotifier;
    private final CashoutSpmMapper cashoutSpmMapper;

    @Override
    public String documentType() {
        return "CASHOUT";
    }

    @Override
    public SpmAnalyzeRequest buildAnalyzeRequest(Cashout cashout) {
        return cashoutSpmMapper.toAnalyzeRequest(cashout);
    }

    @Override
    public SpmOutcome onAllow(Cashout cashout) {
        createFrkkTask(cashout);
        return SpmOutcome.PROCEED;
    }

    @Override
    public SpmOutcome onDeny(Cashout cashout) {
        cashout.setStatusCode(CashoutStatusCode.DENIED);
        cashout.setSubstatusCode(CashoutSubstatusCode.DENIED_SPM);
        setNotification(cashout, CashoutNotificationCode.DENIED_SPM);
        cashoutRepository.saveAndFlush(cashout);

        linkedApplicationPort.denyBySpm(cashout.getApplicationId());
        return SpmOutcome.STOP;
    }

    @Override
    public SpmOutcome onReview(Cashout cashout) {
        LinkedApplication application = linkedApplication(cashout);

        if (isTechnicalAllow(cashout, application)) {
            cashout.setSpmActionCode(ActionCode.AUTO_ALLOW);
            cashout.setSpmActionTimestamp(OffsetDateTime.now());
            createFrkkTask(cashout);
            activityNotifier.execute(cashout, TECH_ALLOW_DESCRIPTION);
            return SpmOutcome.PROCEED;
        }

        cashout.setStatusCode(CashoutStatusCode.CONTROL_SPM);
        cashout.setSubstatusCode(null);
        cashout.setSpmDeadline(cashout.getSpmActionTimestamp().plusHours(2));
        setNotification(cashout, CashoutNotificationCode.SPM_CHECK_2);
        cashoutRepository.saveAndFlush(cashout);
        return SpmOutcome.STOP;
    }

    @Override
    public SpmOutcome onUnexpected(Cashout cashout) {
        createFrkkTask(cashout);
        // для расходного документа EXECUTE отправляется сразу, не по результату создания задачи
        activityNotifier.execute(cashout, SpmActivityNotifier.UNEXPECTED_RESOLUTION);
        return SpmOutcome.PROCEED;
    }

    @Override
    public SpmOutcome onTechChallenge(Cashout cashout) {
        createFrkkTask(cashout);
        return SpmOutcome.PROCEED;
    }

    /**
     * (cashout.spm_action_timestamp - application.created_timestamp) < 12 ч
     * и application.spm_action_code = REVIEW_ALLOW.
     */
    private boolean isTechnicalAllow(Cashout cashout, LinkedApplication application) {
        Duration sinceApplication = Duration.between(
                application.createdTimestamp(),
                cashout.getSpmActionTimestamp().toInstant());
        return sinceApplication.compareTo(TECH_ALLOW_WINDOW) < 0
                && application.spmActionCode() == ActionCode.REVIEW_ALLOW;
    }

    private void setNotification(Cashout cashout, CashoutNotificationCode code) {
        cashout.setNotificationCode(code);
        cashout.setReasonDescription(cashoutNotificationRepository.getDescriptionByCode(code));
    }

    private void createFrkkTask(Cashout cashout) {
        cashoutRepository.saveAndFlush(cashout);
        cashoutFrkkTaskService.createControllerTask(cashout);
    }

    private LinkedApplication linkedApplication(Cashout cashout) {
        return linkedApplicationPort.find(cashout.getApplicationId())
                .orElseThrow(() -> new IllegalStateException(
                        "Не найдена заявка " + cashout.getApplicationId() + " для расходного документа " + cashout.getId()));
    }
}
