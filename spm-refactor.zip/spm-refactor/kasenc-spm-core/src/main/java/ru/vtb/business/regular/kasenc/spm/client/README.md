# Перенести сюда из bank-cash-business-logic

Всё, что относится к интерфейсу checks-fraud 1737 и не зависит от конкретного документа:

- `CheckFraudLegalClient` (Feign-клиент) — url берётся из свойства, его нужно задать в application.yml
  каждого приложения, которое подключает ядро;
- DTO `analyze` и `update/activity`: `SpmAnalyzeRequest`, `SpmAnalyzeResponse` (с `RiskResult`, `TriggeredRule`),
  запрос update/activity;
- enum'ы `ActionCode` (ALLOW, DENY, REVIEW, CHALLENGE, AUTO_ALLOW, REVIEW_ALLOW, ...) и `UpdateType`;
- `SpmActivityMapper` — метод `mapToUpdateActivity(UpdateType, String description, String actionSubCode)`
  из `SpmMapper`, без `componentModel = "spring"`.

В `SpmMapper` модуля заявок остаётся только `mapApplicationToSAVOBSKAnalyzeRequest`.
Маппинг документа в запрос analyze — у каждого модуля свой.

Имена классов в ядре — те, что видны на скриншотах; если реальные отличаются, поправьте импорты.
