package ru.vtb.business.regular.kasenc.spm;

/**
 * Порт метрик. Ядро не знает про BankCashMonitoring (он в модуле bank-cash):
 * модуль может зарегистрировать свою реализацию, иначе используется MicrometerSpmMetrics.
 */
public interface SpmMetrics {

    void increment(SpmResolution resolution, String documentType);
}
