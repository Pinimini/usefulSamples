package ru.vtb.business.regular.kasenc.spm;

import lombok.RequiredArgsConstructor;
import ru.vtb.business.regular.kasenc.spm.client.CheckFraudLegalClient;
import ru.vtb.business.regular.kasenc.spm.client.SpmActivityMapper;
import ru.vtb.business.regular.kasenc.spm.client.UpdateType;

/**
 * POST /api/v1/checks_fraud/legal/update/activity (resolution=UNKNOWN проставляет маппер — проверить).
 * Бин создаётся в SpmCoreAutoConfiguration.
 */
@RequiredArgsConstructor
public class SpmActivityNotifier {

    public static final String UNEXPECTED_RESOLUTION = "Получена непредусмотренная резолюция";
    public static final String UNEXPECTED_RESOLUTION_CANCELLED =
            "Получена непредусмотренная резолюция. Операция отменена по техническим причинам";

    private final CheckFraudLegalClient checkFraudClient;
    private final SpmActivityMapper activityMapper;

    public void execute(SpmDocument document, String description) {
        send(document, UpdateType.EXECUTE, description);
    }

    public void cancel(SpmDocument document, String description) {
        send(document, UpdateType.CANCEL, description);
    }

    private void send(SpmDocument document, UpdateType type, String description) {
        checkFraudClient.updateActivity(activityMapper.mapToUpdateActivity(type, description, null),
                document.getProductTypeCode().name(), document.getId(), null);
    }
}
