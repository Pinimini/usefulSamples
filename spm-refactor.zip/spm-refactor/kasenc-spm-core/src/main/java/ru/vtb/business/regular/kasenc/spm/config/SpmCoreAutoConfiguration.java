package ru.vtb.business.regular.kasenc.spm.config;

import io.micrometer.core.instrument.MeterRegistry;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import ru.vtb.business.regular.kasenc.spm.MicrometerSpmMetrics;
import ru.vtb.business.regular.kasenc.spm.SpmActivityNotifier;
import ru.vtb.business.regular.kasenc.spm.SpmCheckProcessor;
import ru.vtb.business.regular.kasenc.spm.SpmMetrics;
import ru.vtb.business.regular.kasenc.spm.client.CheckFraudLegalClient;
import ru.vtb.business.regular.kasenc.spm.client.SpmActivityMapper;

/**
 * Подключается автоматически в любом boot-приложении, где kasenc-spm-core на classpath
 * (META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports).
 * Модулям документов не нужно расширять @ComponentScan на пакет ядра.
 *
 * Если @EnableFeignClients приложения сканирует пакет ru.vtb.business.regular.kasenc целиком,
 * CheckFraudLegalClient зарегистрируется дважды — сузьте basePackages приложения или уберите аннотацию здесь.
 */
@AutoConfiguration
@EnableFeignClients(clients = CheckFraudLegalClient.class)
public class SpmCoreAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public SpmActivityMapper spmActivityMapper() {
        // маппер в ядре объявлен без componentModel = "spring", чтобы не зависеть от сканирования
        return Mappers.getMapper(SpmActivityMapper.class);
    }

    @Bean
    @ConditionalOnMissingBean
    public SpmMetrics spmMetrics(ObjectProvider<MeterRegistry> meterRegistry) {
        return new MicrometerSpmMetrics(meterRegistry);
    }

    @Bean
    @ConditionalOnMissingBean
    public SpmCheckProcessor spmCheckProcessor(CheckFraudLegalClient checkFraudClient, SpmMetrics spmMetrics) {
        return new SpmCheckProcessor(checkFraudClient, spmMetrics);
    }

    @Bean
    @ConditionalOnMissingBean
    public SpmActivityNotifier spmActivityNotifier(CheckFraudLegalClient checkFraudClient,
                                                   SpmActivityMapper spmActivityMapper) {
        return new SpmActivityNotifier(checkFraudClient, spmActivityMapper);
    }
}
