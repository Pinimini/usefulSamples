package ru.vtb.business.regular.kasenc.spm;

import feign.FeignException;
import java.time.OffsetDateTime;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ru.vtb.business.regular.kasenc.spm.client.CheckFraudLegalClient;
import ru.vtb.business.regular.kasenc.spm.client.SpmAnalyzeResponse;

/**
 * Общий сценарий проверки в СПМ для любого документа:
 * analyze -> резолюция -> метрика -> spm_action_code/timestamp -> реакция документа -> PROCEED/STOP.
 *
 * Бин создаётся в SpmCoreAutoConfiguration.
 * Не помечать @Transactional: внутри HTTP-вызов checks-fraud, держать на нём транзакцию БД нельзя.
 */
@Slf4j
@RequiredArgsConstructor
public class SpmCheckProcessor {

    private final CheckFraudLegalClient checkFraudClient;
    private final SpmMetrics spmMetrics;

    public <D extends SpmDocument> SpmCheckResult check(D document, SpmDocumentHandler<D> handler) {
        String documentType = handler.documentType();
        log.info("Выполняются проверки чекфрод: {} {}", documentType, document.getId());

        SpmResolution resolution = analyze(document, handler);
        log.info("Резолюция СПМ для {} {}: {}", documentType, document.getId(), resolution);

        spmMetrics.increment(resolution, documentType);
        document.setSpmActionCode(resolution.getSpmActionCode());
        document.setSpmActionTimestamp(OffsetDateTime.now());

        // switch без default: новая резолюция не скомпилируется, пока её не обработают все модули
        SpmOutcome outcome = switch (resolution) {
            case ALLOW -> handler.onAllow(document);
            case DENY -> handler.onDeny(document);
            case REVIEW -> handler.onReview(document);
            case UNEXPECTED -> handler.onUnexpected(document);
            case TECH_CHALLENGE -> handler.onTechChallenge(document);
        };
        log.info("Проверка СПМ для {} {} завершена: {}", documentType, document.getId(), outcome);
        return new SpmCheckResult(resolution, outcome);
    }

    private <D extends SpmDocument> SpmResolution analyze(D document, SpmDocumentHandler<D> handler) {
        try {
            SpmAnalyzeResponse response = checkFraudClient.analyze(handler.buildAnalyzeRequest(document),
                    document.getProductTypeCode().name(), document.getId(), null);
            return SpmResolutionResolver.resolve(response);
        } catch (FeignException e) {
            // Строка "exceptions / 5xx / 4xx (кроме 400, 404)" — в аналитике помечена "уточнить"
            if (e.status() == 400 || e.status() == 404) {
                throw e;
            }
            log.error("Ошибка вызова check-fraud для {}, применяется резолюция по умолчанию", document.getId(), e);
            return SpmResolution.TECH_CHALLENGE;
        }
    }
}
