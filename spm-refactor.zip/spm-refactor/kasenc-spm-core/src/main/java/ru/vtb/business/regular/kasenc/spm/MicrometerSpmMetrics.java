package ru.vtb.business.regular.kasenc.spm;

import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.ObjectProvider;

/**
 * Реализация по умолчанию: счётчик с именем из аналитики и тегом типа документа
 * (имена метрик у заявки, расходного и приходного документов одинаковые — без тега их не различить).
 *
 * Если то же имя метрики уже регистрирует BankCashMonitoring без тега — используйте его адаптер
 * (BankCashSpmMetrics), иначе Prometheus-реестр отклонит счётчик с другим набором тегов.
 */
@RequiredArgsConstructor
public class MicrometerSpmMetrics implements SpmMetrics {

    private static final String DOCUMENT_TYPE_TAG = "document_type";

    private final ObjectProvider<MeterRegistry> meterRegistry;

    @Override
    public void increment(SpmResolution resolution, String documentType) {
        meterRegistry.ifAvailable(registry -> registry
                .counter(resolution.getMetricName(), DOCUMENT_TYPE_TAG, documentType)
                .increment());
    }
}
